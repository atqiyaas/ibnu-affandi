-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 21 Jan 2019 pada 20.46
-- Versi Server: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `skripsi_ibnu`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `bayi`
--

CREATE TABLE `bayi` (
  `no_bayi` int(11) NOT NULL,
  `nama_ibu` varchar(255) NOT NULL,
  `nama_bayi` varchar(100) DEFAULT NULL,
  `tanggal_kelahiran` date DEFAULT NULL,
  `jenis_persalinan` varchar(100) DEFAULT NULL,
  `jenis_kelamin` enum('L','P') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bayi`
--

INSERT INTO `bayi` (`no_bayi`, `nama_ibu`, `nama_bayi`, `tanggal_kelahiran`, `jenis_persalinan`, `jenis_kelamin`) VALUES
(3, 'Savira Razak', 'sabeea salsabila', '2018-12-11', 'sesar', 'P');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kontrolbayi`
--

CREATE TABLE `kontrolbayi` (
  `no_kontrol` int(11) NOT NULL,
  `no_pk` varchar(3) NOT NULL,
  `no_bayi` varchar(100) DEFAULT NULL,
  `berat_badan` varchar(100) DEFAULT NULL,
  `frekuensi_jantung` varchar(100) DEFAULT NULL,
  `suhu_badan` varchar(100) DEFAULT NULL,
  `usaha_bernafas` varchar(100) DEFAULT NULL,
  `lingkar_kepala` varchar(100) DEFAULT NULL,
  `tonus_otot` varchar(100) DEFAULT NULL,
  `warna_kulit` varchar(100) DEFAULT NULL,
  `panjang_badan` varchar(100) DEFAULT NULL,
  `lingkar_dada` varchar(100) DEFAULT NULL,
  `lebar_hidung` varchar(100) DEFAULT NULL,
  `berkedip` varchar(100) DEFAULT NULL,
  `moros` varchar(100) DEFAULT NULL,
  `menggenggam` varchar(100) DEFAULT NULL,
  `rooting` varchar(100) DEFAULT NULL,
  `menghisap` varchar(100) DEFAULT NULL,
  `tanggal_pemeriksaan` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kontrolbayi`
--

INSERT INTO `kontrolbayi` (`no_kontrol`, `no_pk`, `no_bayi`, `berat_badan`, `frekuensi_jantung`, `suhu_badan`, `usaha_bernafas`, `lingkar_kepala`, `tonus_otot`, `warna_kulit`, `panjang_badan`, `lingkar_dada`, `lebar_hidung`, `berkedip`, `moros`, `menggenggam`, `rooting`, `menghisap`, `tanggal_pemeriksaan`) VALUES
(1, 'pk1', '3', '8', '33', '23', 'Normal', '23', 'Gerak Aktif', 'Semua Kemerahan', '70', '17', NULL, 'Cepat', 'Cepat', 'Lemah', 'Bayi Reflek Searah', 'Cepat Kuat', '20 January 2019'),
(2, 'pk2', '3', '12', '89', '25', 'Normal', '45', 'Gerak Aktif', 'Kemerahan Atas Biru', '17', '11', NULL, 'Lambat', 'Lambat', 'Kuat', 'Tidak', 'Lemah Kuat', '20 January 2019'),
(3, 'pk3', '3', '11', '12', '13', 'Normal', '14', 'Gerak Aktif', 'Semua Kemerahan', '15', '16', NULL, 'Cepat', 'Cepat', 'Lemah', 'Bayi Reflek Searah', 'Cepat Kuat', '20 January 2019');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pasien`
--

CREATE TABLE `pasien` (
  `no_pasien` int(100) NOT NULL,
  `id_pegawai` int(11) DEFAULT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `alamat` text,
  `no_telpon` varchar(100) DEFAULT NULL,
  `no_identitas` int(20) DEFAULT NULL,
  `jenis_identitas` varchar(100) DEFAULT NULL,
  `jenis_kelamin` enum('L','P') DEFAULT NULL,
  `status_pasien` enum('aktif','nonaktif') DEFAULT 'aktif',
  `nama_suami` varchar(100) DEFAULT NULL,
  `usia_pernikahan` varchar(100) DEFAULT NULL,
  `jenis_kb` varchar(100) DEFAULT NULL,
  `tanggal_hpht` date DEFAULT NULL,
  `tanggal_hpl` date DEFAULT NULL,
  `lama_pemakaian` varchar(100) DEFAULT NULL,
  `hamil_ke` varchar(100) DEFAULT NULL,
  `jumlah_anak` varchar(100) DEFAULT NULL,
  `riwayat_keguguran` enum('ya','tidak') DEFAULT NULL,
  `riwayat_persalinan` varchar(100) DEFAULT NULL,
  `kesehatan_bayi` varchar(100) DEFAULT NULL,
  `berat_badan` varchar(100) DEFAULT NULL,
  `jenis_persalinan` varchar(100) DEFAULT NULL,
  `tempat_persalinan` varchar(100) DEFAULT NULL,
  `usia_kehamilan` varchar(100) DEFAULT NULL,
  `pernah_hamil` enum('ya','tidak') DEFAULT NULL,
  `tgl1` varchar(50) NOT NULL,
  `tgl2` varchar(50) NOT NULL,
  `tg3` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pasien`
--

INSERT INTO `pasien` (`no_pasien`, `id_pegawai`, `nama`, `alamat`, `no_telpon`, `no_identitas`, `jenis_identitas`, `jenis_kelamin`, `status_pasien`, `nama_suami`, `usia_pernikahan`, `jenis_kb`, `tanggal_hpht`, `tanggal_hpl`, `lama_pemakaian`, `hamil_ke`, `jumlah_anak`, `riwayat_keguguran`, `riwayat_persalinan`, `kesehatan_bayi`, `berat_badan`, `jenis_persalinan`, `tempat_persalinan`, `usia_kehamilan`, `pernah_hamil`, `tgl1`, `tgl2`, `tg3`) VALUES
(1, 1, 'Savira Razak', 'Salah jalan sama pacar orang', '0812345678', 123456789, NULL, 'P', 'aktif', 'Cahyo Purnomo Putro', '3 tahun', 'spiral', '2018-12-02', '2018-12-12', '12 bulan', '2', '1', 'ya', 'Y', 'Y', '70', 'N', 'dukun', '7 bulan', '', '2018-12-25 16:59:04', '2018-12-25 16:59:04', '2018-12-25 16:59:04'),
(2, 1, 'Maesaroh', 'ALamat lengkap gua nih', '08123412341234', 987654321, NULL, 'P', 'aktif', 'Fadil', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tidak', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-12-25 16:59:04', '2018-12-25 16:59:04', '2018-12-25 16:59:04'),
(3, 1, 'annelia', 'keroncong permai', '0812345678', 1455201232, NULL, 'P', 'aktif', 'abrorr', '12 tahun', 'pil', '2018-12-10', '2018-12-12', '10 tahun', '2', '1', 'tidak', 'T', 'sehat banget', '1', 'bp', NULL, '6', 'ya', '25 December 2018', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pegawai`
--

CREATE TABLE `pegawai` (
  `id_pegawai` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `alamat` text,
  `telpon` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(250) DEFAULT NULL,
  `jabatan` enum('1','2','3','4') DEFAULT NULL,
  `no_identitas` int(20) DEFAULT NULL,
  `jenis_kelamin` enum('L','P') DEFAULT NULL,
  `status_pegawai` enum('aktif','nonaktif') DEFAULT 'aktif'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pegawai`
--

INSERT INTO `pegawai` (`id_pegawai`, `nama`, `alamat`, `telpon`, `username`, `password`, `jabatan`, `no_identitas`, `jenis_kelamin`, `status_pegawai`) VALUES
(1, 'Syifa Fauziah', 'Alamat lengkap saya disini', '0812345678', 'syifa', 'd8578edf8458ce06fbc5bb76a58c5ca4', '3', 123456789, 'L', 'aktif'),
(2, 'atqiya', 'kemiri', '0812345678', 'atqiya', 'd8578edf8458ce06fbc5bb76a58c5ca4', '2', 12345, 'P', 'nonaktif'),
(4, 'administrator', 'deep web', '0895330160610', 'admin', '21232f297a57a5a743894a0e4a801fc3', '1', 1455201232, 'L', 'aktif');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemeriksaankehamilan`
--

CREATE TABLE `pemeriksaankehamilan` (
  `no_pemeriksaan` int(11) NOT NULL,
  `no_pasien` varchar(100) DEFAULT NULL,
  `no_pk` varchar(255) NOT NULL,
  `umur_kehamilan` varchar(100) DEFAULT NULL,
  `fundusuteri` varchar(100) DEFAULT NULL,
  `bagian_perut_atas` varchar(100) DEFAULT NULL,
  `bagian_perut_bawah` varchar(100) DEFAULT NULL,
  `bagian_perut_kanan` varchar(100) DEFAULT NULL,
  `bagian_perut_kiri` varchar(100) DEFAULT NULL,
  `bagian_panggul` varchar(100) DEFAULT NULL,
  `keterangan_bagian_panggul` varchar(100) DEFAULT NULL,
  `tanggal_pemeriksaan` varchar(50) NOT NULL,
  `status_periksa` enum('AKTIF','NONAKTIF') DEFAULT 'AKTIF'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pemeriksaankehamilan`
--

INSERT INTO `pemeriksaankehamilan` (`no_pemeriksaan`, `no_pasien`, `no_pk`, `umur_kehamilan`, `fundusuteri`, `bagian_perut_atas`, `bagian_perut_bawah`, `bagian_perut_kanan`, `bagian_perut_kiri`, `bagian_panggul`, `keterangan_bagian_panggul`, `tanggal_pemeriksaan`, `status_periksa`) VALUES
(2, '3', 'pk1', '6', '1', '2', '3', '4', '5', '6', '7', '26 December 2018', 'AKTIF'),
(3, '1', 'pk1', '7 bulan', '1', '2', '3', '4', '5', '6', '7', '12 January 2019', 'AKTIF'),
(4, '1', 'pk2', '7 bulan', '12', '22', '32', '42', '52', '62', '72', '12 January 2019', 'AKTIF'),
(5, '1', 'pk3', '7 bulan', '31', '32', '33', '34', '35', '36', '37', '12 January 2019', 'AKTIF');

-- --------------------------------------------------------

--
-- Struktur dari tabel `perbandingankehamilan`
--

CREATE TABLE `perbandingankehamilan` (
  `perbandingan_periksa` varchar(100) DEFAULT NULL,
  `no_pasien` varchar(100) DEFAULT NULL,
  `catatan` text,
  `dari_tanggal` date DEFAULT NULL,
  `sampai_tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `perbandingankontrolbayi`
--

CREATE TABLE `perbandingankontrolbayi` (
  `perbandingan_kontrol_bayi` varchar(100) NOT NULL,
  `no_bayi` varchar(100) DEFAULT NULL,
  `catatan` text,
  `dari_tanggal` date DEFAULT NULL,
  `sampai_tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `rawatinap`
--

CREATE TABLE `rawatinap` (
  `no_rawat_inap` int(11) NOT NULL,
  `nama_ruangan` varchar(100) DEFAULT NULL,
  `no_kasur` varchar(11) DEFAULT NULL,
  `nama_pasien` varchar(100) DEFAULT NULL,
  `tanggal_masuk` varchar(50) DEFAULT NULL,
  `tanggal_keluar` varchar(50) NOT NULL DEFAULT '-',
  `status_rawat` enum('Masuk','Keluar') NOT NULL DEFAULT 'Masuk'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `rawatinap`
--

INSERT INTO `rawatinap` (`no_rawat_inap`, `nama_ruangan`, `no_kasur`, `nama_pasien`, `tanggal_masuk`, `tanggal_keluar`, `status_rawat`) VALUES
(4, NULL, NULL, 'Savira Razak', '12 January 2019', '21 January 2019', 'Keluar'),
(5, 'MELATI', '02', 'Maesaroh', '12 January 2019', '-', 'Masuk');

-- --------------------------------------------------------

--
-- Struktur dari tabel `riwayatkesehatan`
--

CREATE TABLE `riwayatkesehatan` (
  `id_rk` int(11) NOT NULL,
  `no_rk` varchar(100) NOT NULL,
  `keadaan_umum` varchar(100) DEFAULT NULL,
  `kesadaran_pasien` varchar(100) DEFAULT NULL,
  `tensi_darah` varchar(100) DEFAULT NULL,
  `berat_badan` varchar(100) DEFAULT NULL,
  `denyut_nadi` varchar(100) DEFAULT NULL,
  `suhu_badan` varchar(100) DEFAULT NULL,
  `tanggal_pemeriksaan` varchar(50) DEFAULT NULL,
  `no_pasien` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `riwayatkesehatan`
--

INSERT INTO `riwayatkesehatan` (`id_rk`, `no_rk`, `keadaan_umum`, `kesadaran_pasien`, `tensi_darah`, `berat_badan`, `denyut_nadi`, `suhu_badan`, `tanggal_pemeriksaan`, `no_pasien`) VALUES
(1, 'rk1', 'Oke', 'Sadar', '120', '65', 'Normal', '24', '25 December 2018', 3),
(2, 'rk1', 'umum', 'Sadar', '120', '66', '30', '25', '12 January 2019', 1),
(3, 'rk2', 'umum2', 'Sadar', '130', '72', '40', '27', '12 January 2019', 1),
(4, 'rk3', 'umum3`', 'Sadar banget', '125', '80', '35', '33', '12 January 2019', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `ruangan`
--

CREATE TABLE `ruangan` (
  `no_ruangan` int(100) NOT NULL,
  `nama_ruangan` varchar(100) DEFAULT NULL,
  `no_kasur` varchar(50) NOT NULL,
  `status_kamar` enum('kosong','dipakai') NOT NULL DEFAULT 'kosong'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `ruangan`
--

INSERT INTO `ruangan` (`no_ruangan`, `nama_ruangan`, `no_kasur`, `status_kamar`) VALUES
(1, 'MAWAR', '01', 'kosong'),
(2, 'MAWAR', '02', 'kosong'),
(3, 'MAWAR', '03', 'kosong'),
(4, 'MAWAR', '04', 'kosong'),
(5, 'MELATI', '01', 'dipakai'),
(6, 'MELATI', '02', 'kosong'),
(7, 'MELATI', '03', 'kosong'),
(8, 'MELATI', '04', 'kosong');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bayi`
--
ALTER TABLE `bayi`
  ADD PRIMARY KEY (`no_bayi`);

--
-- Indexes for table `kontrolbayi`
--
ALTER TABLE `kontrolbayi`
  ADD PRIMARY KEY (`no_kontrol`),
  ADD KEY `no_bayi` (`no_bayi`);

--
-- Indexes for table `pasien`
--
ALTER TABLE `pasien`
  ADD PRIMARY KEY (`no_pasien`);

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`id_pegawai`);

--
-- Indexes for table `pemeriksaankehamilan`
--
ALTER TABLE `pemeriksaankehamilan`
  ADD PRIMARY KEY (`no_pemeriksaan`);

--
-- Indexes for table `perbandingankontrolbayi`
--
ALTER TABLE `perbandingankontrolbayi`
  ADD PRIMARY KEY (`perbandingan_kontrol_bayi`);

--
-- Indexes for table `rawatinap`
--
ALTER TABLE `rawatinap`
  ADD PRIMARY KEY (`no_rawat_inap`);

--
-- Indexes for table `riwayatkesehatan`
--
ALTER TABLE `riwayatkesehatan`
  ADD PRIMARY KEY (`id_rk`);

--
-- Indexes for table `ruangan`
--
ALTER TABLE `ruangan`
  ADD PRIMARY KEY (`no_ruangan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bayi`
--
ALTER TABLE `bayi`
  MODIFY `no_bayi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `kontrolbayi`
--
ALTER TABLE `kontrolbayi`
  MODIFY `no_kontrol` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `pasien`
--
ALTER TABLE `pasien`
  MODIFY `no_pasien` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `pegawai`
--
ALTER TABLE `pegawai`
  MODIFY `id_pegawai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `pemeriksaankehamilan`
--
ALTER TABLE `pemeriksaankehamilan`
  MODIFY `no_pemeriksaan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `rawatinap`
--
ALTER TABLE `rawatinap`
  MODIFY `no_rawat_inap` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `riwayatkesehatan`
--
ALTER TABLE `riwayatkesehatan`
  MODIFY `id_rk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `ruangan`
--
ALTER TABLE `ruangan`
  MODIFY `no_ruangan` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
