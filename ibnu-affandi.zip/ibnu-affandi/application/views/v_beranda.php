<!-- Page Title -->
<div class="container mt-0">
	<div class="row breadcrumb-bar">
		<div class="col-md-6">
			<h3 class="block-title"><?php echo $this->session->userdata('nama'); ?></h3>
		</div>
		<div class="col-md-6">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="index-2.html">
						<span class="ti-home"> </span>Klinik 
					</a>
				</li>
				<li class="breadcrumb-item active"><?php echo $title ?></li>
			</ol>
		</div>
	</div>
</div>
<!-- Main Content -->
<div class="container home">
	<div class="row">
		<div class="col-md-4">
			<div class="widget-area lochana-box-shadow color-blue">
				<div class="widget-left">
					<span class="ti-user"></span>
				</div>
				<div class="widget-right">
					<h4 class="wiget-title">Pasien</h4>
					<span class="numeric color-blue"><?php echo $this->db->get('pasien')->num_rows(); ?> Pasien</span>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="widget-area lochana-box-shadow color-green">
				<div class="widget-left">
					<span class="ti-face-smile"></span>
				</div>
				<div class="widget-right">
					<h4 class="wiget-title">Bayi</h4>
					<span class="numeric color-green"><?php echo $this->db->get('bayi')->num_rows(); ?> Bayi</span>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="widget-area lochana-box-shadow color-blue">
				<div class="widget-left">
					<span class="ti-layout-grid3-alt"></span>
				</div>
				<div class="widget-right">
					<h4 class="wiget-title">Pasien Rawat Inap</h4>
					<span class="numeric color-blue"><?php echo $this->rsia->get_where('rawatinap', array('status_rawat'=>'Masuk'))->num_rows(); ?> Pasien</span>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="widget-area lochana-box-shadow color-green">
				<div class="widget-left">
					<span class="ti-user"></span>
				</div>
				<div class="widget-right">
					<h4 class="wiget-title">Jumlah Pegawai</h4>
					<span class="numeric color-green"><?php echo $this->db->get('pegawai')->num_rows(); ?> Orang</span>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="widget-area lochana-box-shadow color-blue">
				<div class="widget-left">
					<span class="ti-layout-grid3-alt"></span>
				</div>
				<div class="widget-right">
					<h4 class="wiget-title">Jumlah Dokter dan Bidan</h4>
					<span class="numeric color-blue"><?php echo $this->rsia->get_where('pegawai', array('jabatan' => '2'))->num_rows(); ?> Orang</span>
				</div>
			</div>
		</div>
		
		<div class="col-md-4">
			<div class="widget-area lochana-box-shadow color-green">
				<div class="widget-left">
					<span class="ti-layout-grid3-alt"></span>
				</div>
				<div class="widget-right">
					<h4 class="wiget-title">Jumlah Petugas Rawat</h4>
					<span class="numeric color-blue"><?php echo $this->rsia->get_where('pegawai', array('jabatan' => '3'))->num_rows(); ?> Orang</span>
				</div>
			</div>
		</div>

		<div class="col-md-4">
			<div class="widget-area lochana-box-shadow color-yellow">
				<div class="widget-left">
					<span class="ti-layout-grid3-alt"></span>
				</div>
				<div class="widget-right">
					<h4 class="wiget-title">Kamar Terpakai</h4>
					<span class="numeric color-yellow"><?php echo $this->rsia->get_where('ruangan', array('status_kamar' => 'dipakai'))->num_rows(); ?> Kamar</span>
				</div>
			</div>
		</div>

		<div class="col-md-4">
			<div class="widget-area lochana-box-shadow color-yellow">
				<div class="widget-left">
					<span class="ti-layout-grid3-alt"></span>
				</div>
				<div class="widget-right">
					<h4 class="wiget-title">Kamar Tersedia (Kosong)</h4>
					<span class="numeric color-yellow"><?php echo $this->rsia->get_where('ruangan', array('status_kamar' => 'kosong'))->num_rows(); ?> Kamar</span>
				</div>
			</div>
		</div>

		<div class="col-md-4">
			<div class="widget-area lochana-box-shadow color-yellow">
				<div class="widget-left">
					<span class="ti-layout-grid3-alt"></span>
				</div>
				<div class="widget-right">
					<h4 class="wiget-title">Total Kamar</h4>
					<span class="numeric color-yellow"><?php echo $this->db->get('ruangan')->num_rows(); ?> Kamar</span>
				</div>
			</div>
		</div>
	</div>
</div>
