
<!DOCTYPE html>
<html>


<!-- Mirrored from konnectplugins.com/proclinic/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 18 Nov 2018 00:19:49 GMT -->
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Skripsi Ibnu Affandi</title>
	<!-- Fav  Icon Link -->
	<link rel="shortcut icon" type="image/png" href="<?php echo base_url() ?>assets/images/fav.png">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/bootstrap.min.css">
	<!-- themify icons CSS -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/themify-icons.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/styles.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/green.css" id="style_theme">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/responsive.css">

	<script src="<?php echo base_url() ?>assets/js/modernizr.min.js"></script>
</head>

<body class="auth-bg">
	<!-- Pre Loader -->
	<div class="loading">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
	</div>
	<!--/Pre Loader -->
	
	<div class="wrapper mt-5">
		<!-- Page Content  -->
		<div id="content">
			<div class="container">
				<div class="row">
					<div class="col-sm-6 auth-box">
						<div class="lochana-box-shadow">
							<h3 class="widget-title">LOGIN</h3>
							<small class="text-capitalize">Silahkan Masukan username & password anda</small><br>
							<?php if(isset($error)) { echo $error; }; ?>

							<form class="widget-form" action="<?php echo base_url() ?>login" method="POST">
								<!-- form-group -->
								<div class="form-group row">
									<div class="col-sm-12">
										<input name="username" placeholder="Username" class="form-control" required autofocus>
									</div>
								</div>
								<!-- /.form-group -->
								<!-- form-group -->
								<div class="form-group row">
									<div class="col-sm-12">
										<input type="password" placeholder="Password" name="password" class="form-control" required> 
									</div>
								</div>
								<!-- /.form-group -->
								<!-- Login Button -->			
								<div class="button-btn-block">
									<button type="submit" name="submit" value="Submit" class="btn btn-primary btn-lg btn-block">Login</button>
								</div>
								<!-- /Login Button -->	
								<!-- Links -->	
								<div class="auth-footer-text text-capitalize">
									<small>Program ini hanya untuk memenuhi persyaratan Tugas Akhir</small><br>
									<b>Teknik informatika</b><br>
									<b>Universitas Muhammadiyah Tangerang</b><br>
									<b>2019</b>
								</div>
								<!-- /Links -->
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- /Page Content  -->
	</div>
	<!-- Jquery Library-->
	<script src="<?php echo base_url() ?>assets/js/jquery-3.2.1.min.js"></script>
	<!-- Popper Library-->
	<script src="<?php echo base_url() ?>assets/js/popper.min.js"></script>
	<!-- Bootstrap Library-->
	<script src="<?php echo base_url() ?>assets/js/bootstrap.min.js"></script>
	<!-- Custom Script-->
	<script src="<?php echo base_url() ?>assets/js/custom.js"></script>
</body>


<!-- Mirrored from konnectplugins.com/proclinic/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 18 Nov 2018 00:19:49 GMT -->
</html>