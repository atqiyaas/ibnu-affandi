<!-- Page Title -->
<div class="container mt-0">
	<div class="row breadcrumb-bar">
		<div class="col-md-6">
			<h3 class="block-title"><?php echo $this->session->userdata('nama'); ?></h3>
		</div>
		<div class="col-md-6">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="<?php echo base_url('home') ?>">
						<span class="ti-home"> </span>Klinik 
					</a>
				</li>
				<li class="breadcrumb-item active"><?php echo $title ?></li>
			</ol>
		</div>
	</div>
</div>
<div class="container">

	<div class="row">
		<!-- Widget Item -->
		<div class="col-md-12">
			<div class="widget-area-2 lochana-box-shadow">
				<h3 class="widget-title text-center"><?php echo $title ?></h3>
				<a href="<?php echo base_url('rawatinap/tambah') ?>" class="btn btn-md btn-primary"><i class="fa fa-plus"></i> Tambah <?php echo $page ?></a>
				<div class="table-responsive mb-3">
					<table id="tableId" class="table table-hover table-bordered table-striped">
						<thead class="text-center">
							<tr>
								<th>No.</th>
								<th>Nama Ruangan</th>
								<th>Nama Pasien</th>
								<!-- <th>Nama Pasien</th> -->
								<th>Tanggal Masuk</th>
								<th>Tanggal Keluar</th>
								<th>Status Rawat</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody class="text-center">
							<?php
							$no = 1;
							foreach ($rawat->result() as $key) :
								?>
								<tr>
									<td><?php echo $no++; ?></td>
									<td><?php echo $key->nama_ruangan; ?> - <?php echo $key->no_kasur; ?></td>
									<td><?php echo $key->nama_pasien; ?></td>
									<td><?php echo $key->tanggal_masuk; ?></td>
									<td><?php echo $key->tanggal_keluar; ?></td>
									<td><?php echo $key->status_rawat; ?></td>
									<td>
										<?php if ($key->nama_ruangan===NULL): ?>
											<a disabled href="#" class="btn btn-block btn-sm btn-info"  data-toggle="tooltip" data-placement="top" title="Pasien Sudah Pulang"><i class="fa fa-alert"></i> Pasien Keluar</a>

										<?php endif ?>

										<?php if ($key->nama_ruangan!=NULL): ?>
											
											<a href="<?php echo base_url('rawatinap/edit/') ?><?php echo $key->no_rawat_inap ?>" class="btn btn-sm btn-warning"  data-toggle="tooltip" data-placement="top" title="Update Pasien Rawat Inap"><i class="fa fa-pencil"></i>Edit</a>

											<a href="<?php echo base_url('rawatinap/keluar/') ?><?php echo $key->no_rawat_inap ?>" class="btn btn-sm btn-danger"  data-toggle="tooltip" data-placement="top" title="Pasien Diperbolehkan Pulang" onclick="return confirm('Pasien sudah diperbolehkan pulang?')"><i class="fa fa-sign-out"></i>Pulang</a>
										<?php endif ?>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<!-- /Widget Item -->
	</div>
</div>