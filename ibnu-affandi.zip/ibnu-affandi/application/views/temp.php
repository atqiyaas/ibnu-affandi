<!DOCTYPE html>
<html>


<!-- Mirrored from konnectplugins.com/proclinic/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 18 Nov 2018 00:14:58 GMT -->
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php echo $title ?></title>
	<!-- Fav  Icon Link -->
	<link rel="shortcut icon" type="image/png" href="<?php echo base_url() ?>assets/images/fav.png">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/bootstrap.min.css">
	<!-- themify icons CSS -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/themify-icons.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/font-awesome.min.css">
	<!-- Animations CSS -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/animate.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/styles.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/green.css" id="style_theme">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/responsive.css">
	<!-- morris charts -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/charts/css/morris.css">
	<!-- jvectormap -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/jquery-jvectormap.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/datatable/dataTables.bootstrap4.min.css">

	<script src="<?php echo base_url() ?>assets/js/modernizr.min.js"></script>
</head>

<body>
	<!-- Pre Loader -->
	<div class="loading">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
	</div>
	<!--/Pre Loader -->
	<div class="wrapper">		
		<!-- Page Content -->
		<div id="content">
			<!-- Top Navigation -->
			<div class="container top-brand">
				<nav class="navbar navbar-default">			
					<div class="navbar-header">
						<div class="sidebar-header"> <a href="index-2.html"><img src="<?php echo base_url() ?>assets/images/logo-dark.png" class="logo" alt="logo"></a>
						</div>
					</div>
					<ul class="nav justify-content-end">
						<li class="nav-item">
							<a class="nav-link">
								<span title="Fullscreen" class="ti-fullscreen fullscreen"></span>
							</a>							
						</li>
						
						<li class="nav-item">
							<a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true"
							aria-expanded="false">
							<span class="ti-user"></span>
						</a>
						<div class="dropdown-menu lochana-box-shadow2 profile animated flipInY">
							<h5><?php echo $this->session->userdata('username'); ?> <small>(<?php if ($this->session->userdata('hak_akses')==='3') {
								echo 'Rawat Inap';
							} elseif ($this->session->userdata('hak_akses')==='2') {
								echo 'Dokter/Bidan';
							} else {
								echo 'Admin';
							} ?>)</small></h5>
							<a class="dropdown-item" href="#">
								<span class="ti-user"></span> <?php echo $this->session->userdata('nama'); ?></a>
								<a class="dropdown-item" href="<?php echo base_url('login/logout') ?>" onclick="return confirm('Yakin mau logout ???')">
									<span class="ti-power-off"></span> Logout</a>
								</div>
							</li>
						</ul>

					</nav>
				</div>
				<!-- /Top Navigation -->
				<!-- Menu -->
				<div class="container menu-nav">
					<nav class="navbar navbar-expand-lg lochana-bg text-white">
						<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
							<span class="ti-menu text-white"></span></button>

							<div class="collapse navbar-collapse" id="navbarSupportedContent">
								<ul class="navbar-nav mr-auto">

									<li class="nav-item">
										<a class="nav-link" href="<?php echo base_url('home') ?>" ><span class="ti-home"></span> Beranda</a>
									</li>
									<?php if ($this->session->userdata('hak_akses')==='1'): ?>
										<li class="nav-item">
											<a class="nav-link" href="<?php echo base_url('pegawai') ?>" ><span class="ti-user"></span> Data Pegawai</a>
										</li>
									<?php endif ?>

									<li class="nav-item">
										<a class="nav-link" href="<?php echo base_url('rawatinap') ?>" ><span class="ti-home"></span> Data Rawat Inap</a>
									</li>

									<li class="nav-item">
										<a class="nav-link" href="<?php echo base_url('pasien') ?>" ><span class="ti-home"></span> Data Pasien</a>
									</li>

									<li class="nav-item">
										<a class="nav-link" href="<?php echo base_url('bayi') ?>" ><span class="ti-home"></span> Data Bayi</a>
									</li>

								</ul>
							</div>
						</nav>
					</div>

					<?php echo $contents ?>

					<div class="container">
						<div class="card mt-3 bg-info text-white text-center text-capitalize">
							<small class="mt-2">Program ini hanya untuk memenuhi persyaratan Tugas Akhir</small>
							<b>Teknik informatika</b>
							<b>Universitas Muhammadiyah Tangerang</b>
							<b>2019</b>
						</div>
						<div class="d-sm-flex justify-content-center">
							<span class="text-muted text-center d-block d-sm-inline-block">Copyright © 2018 <a href="www.atqiyaishere.com" target="_blank">Skripsi Ibnu</a>. All rights reserved.</span>
						</div>
					</div>
					<!-- /Copy Rights-->
				</div>
				<!-- /Page Content -->
			</div>
			<!-- Back to Top -->
			<a id="back-to-top" href="#" class="back-to-top">
				<span class="ti-angle-up"></span>
			</a>
			<!-- /Back to Top -->
			<!-- Jquery Library-->
			<script src="<?php echo base_url() ?>assets/js/jquery-3.2.1.min.js"></script>
			<!-- Popper Library-->
			<script src="<?php echo base_url() ?>assets/js/popper.min.js"></script>
			<!-- Bootstrap Library-->
			<script src="<?php echo base_url() ?>assets/js/bootstrap.min.js"></script>
			<!-- morris charts -->
			<script src="<?php echo base_url() ?>assets/charts/js/raphael-min.js"></script>
			<script src="<?php echo base_url() ?>assets/charts/js/morris.min.js"></script>
			<script src="<?php echo base_url() ?>assets/js/custom-morris.js"></script>

			<!-- Datatable  -->
			<script src="<?php echo base_url() ?>assets/datatable/jquery.dataTables.min.js"></script>
			<script src="<?php echo base_url() ?>assets/datatable/dataTables.bootstrap4.min.js"></script>

			<!-- Custom Script-->
			<script src="<?php echo base_url() ?>assets/js/custom.js"></script>
			<script src="<?php echo base_url() ?>assets/js/custom-datatables.js"></script>
			<!-- Global site tag (gtag.js) - Google Analytics -->
			<script async src="https://www.googletagmanager.com/gtag/js?id=UA-77800499-1"></script>
			<script>
				window.dataLayer = window.dataLayer || [];
				function gtag(){dataLayer.push(arguments);}
				gtag('js', new Date());

				gtag('config', 'UA-77800499-1');
			</script>

		</body>


		<!-- Mirrored from konnectplugins.com/proclinic/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 18 Nov 2018 00:18:35 GMT -->
		</html>