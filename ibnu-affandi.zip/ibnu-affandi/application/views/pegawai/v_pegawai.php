<!-- Page Title -->
<div class="container mt-0">
	<div class="row breadcrumb-bar">
		<div class="col-md-6">
			<h3 class="block-title"><?php echo $this->session->userdata('nama'); ?></h3>
		</div>
		<div class="col-md-6">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="index-2.html">
						<span class="ti-home"> </span>Klinik 
					</a>
				</li>
				<li class="breadcrumb-item active"><?php echo $title ?></li>
			</ol>
		</div>
	</div>
</div>
<div class="container">

	<div class="row">
		<!-- Widget Item -->
		<div class="col-md-12">
			<div class="widget-area-2 lochana-box-shadow">
				<h3 class="widget-title text-center"><?php echo $title ?></h3>
				<a href="<?php echo base_url('pegawai/tambah') ?>" class="btn btn-md btn-primary"><i class="fa fa-plus"></i> Tambah <?php echo $page ?></a>
				<div class="table-responsive mb-3">
					<table id="tableId" class="table table-hover table-bordered table-striped">
						<thead class="text-center">
							<tr>
								<th>No.</th>
								<th>Nama Lengkap</th>
								<!-- <th>Username</th> -->
								<th>Jabatan</th>
								<th>No. Telephone</th>
								<th>Jenis Kelamin</th>
								<th>Status</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody class="text-center">
							<?php
							$no = 1;
							foreach ($pegawai->result() as $key) :
							?>
							<tr>
								<td><?php echo $no++; ?></td>
								<td><?php echo $key->nama; ?></td>
								<!-- <td><b>@<?php echo $key->username; ?></b></td> -->
								<td><?php if ($key->jabatan == 1) {
									echo 'Admin';
								} elseif ($key->jabatan == 2) {
									echo "Dokter/Bidan";
								} else {
									echo "Petugas Rawat Inap";
								} ?></td>
								<td><?php echo $key->telpon; ?></td>
								<td><?php if ($key->jenis_kelamin == 'L') {
									echo "Laki-laki";
								} else {
									echo "Perempuan";
								} ?></td>
								<td><?php echo $key->status_pegawai; ?></td>
								<td>
									<a href="<?php echo base_url('pegawai/detail/') ?><?php echo $key->id_pegawai ?>" class="btn btn-sm btn-info"><i class="fa fa-eye"></i> Detail</a>
									<a href="<?php echo base_url('pegawai/edit/') ?><?php echo $key->id_pegawai ?>" class="btn btn-sm btn-warning"><i class="fa fa-pencil"></i> Edit</a>
									<a href="<?php echo base_url('pegawai/hapus/') ?><?php echo $key->id_pegawai ?>" onclick="return confirm('Yakin dihapus?')" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> Hapus</a>
								</td>
							</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<!-- /Widget Item -->
	</div>
</div>