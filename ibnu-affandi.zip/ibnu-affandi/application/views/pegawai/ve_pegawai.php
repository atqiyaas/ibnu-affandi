<!-- Page Title -->
<div class="container mt-0">
	<div class="row breadcrumb-bar">
		<div class="col-md-6">
			<h3 class="block-title"><?php echo $title ?></h3>
		</div>
		<div class="col-md-6">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="<?php echo base_url() ?>">
						<span class="ti-home"></span>
					</a>
				</li>
				<li class="breadcrumb-item"><?php echo $page ?></li>
				<li class="breadcrumb-item active"><?php echo $title ?></li>
			</ol>
		</div>
	</div>
</div>
<!-- /Page Title -->
<!-- Main Content -->
<div class="container">

	<div class="row">
		<!-- Widget Item -->
		<div class="col-md-12">
			<div class="widget-area-2 lochana-box-shadow">
				<h3 class="widget-title"><?php $title ?></h3>
				<form method="post"	>
					<div class="form-row">
						
						<div class="form-group col-md-6">
							<label for="dob">No. Identitas</label>
							<input type="text" placeholder="No. Identitas" class="form-control" name="no_id" value="<?php echo $no_id ?>">
						</div>
						<div class="form-group col-md-6">
							<label for="Doctor-name">Nama Lengkap</label>
							<input type="text" class="form-control" placeholder="Nama Lengkap" name="nama" value="<?php echo $nama ?>">
						</div>
						<div class="form-group col-md-6">
							<label for="dob">Username</label>
							<input type="text" placeholder="Username" class="form-control" name="username" value="<?php echo $username ?>">
						</div>
						<div class="form-group col-md-6">
							<label for="dob">No. Telephone</label>
							<input type="text" placeholder="No. Telephone" class="form-control" name="notelp" value="<?php echo $notelp ?>">
						</div>
						<div class="form-group col-md-4">
							<label for="jk">Jenis Kelamin</label>
							<select class="form-control" name="jk">
								<option <?php if ($jk == 'L') {echo "selected";} ?> value="L">Laki-laki</option>
								<option <?php if ($jk == 'P') {echo "selected";} ?> value="P">Perempuan</option>
							</select>
						</div>
						<div class="form-group col-md-4">
							<label for="jabatan">Jabatan</label>
							<select class="form-control" name="jabatan">
								<option value="1">Admin</option>
								<option value="2">Dokter/Bidan</option>
								<option value="3">Pegawai rawat inap</option>
							</select>
						</div>
						<div class="form-group col-md-4">
							<label for="jk">Status</label>
							<select class="form-control" name="status">
								<option <?php if ($status == 'aktif') {echo "selected";} ?> value="aktif">Aktif</option>
								<option <?php if ($status == 'nonaktif') {echo "selected";} ?> value="nonaktif">Nonaktif</option>
							</select>
						</div>
						<div class="form-group col-md-12">
							<label for="about-doctor">Alamat</label>
							<textarea placeholder="Alamat Lengkap" class="form-control" name="alamat" rows="3"><?php echo $alamat ?></textarea>
						</div>
						
						<div class="form-group col-md-6 mb-3">
							<button type="submit" name="submit" value="Submit" class="btn btn-primary btn-lg"><i class="fa fa-save"></i> Update</button>
							<button type="button" onclick="window.history.go(-1)" class="btn btn-danger btn-lg"><i class="fa fa-ban"></i> Batal</button>
						</div>
					</div>
				</form>
			</div>
		</div>
		<!-- /Widget Item -->
	</div>
</div>