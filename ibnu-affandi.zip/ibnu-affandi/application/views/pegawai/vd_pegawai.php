<!-- Page Title -->
<div class="container mt-0">
 <div class="row breadcrumb-bar">
  <div class="col-md-6">
    <h3 class="block-title"><?php echo $title ?></h3>
</div>
<div class="col-md-6">
   <ol class="breadcrumb">
    <li class="breadcrumb-item">
     <a href="<?php echo base_url() ?>">
      <span class="ti-home"></span>
  </a>
</li>
<li class="breadcrumb-item"><?php echo $page ?></li>
<li class="breadcrumb-item active"><?php echo $title ?></li>
</ol>
</div>
</div>
</div>
<!-- /Page Title -->

<!-- /Breadcrumb -->
<!-- Main Content -->
<div class="container">

    <div class="row">
        <!-- Widget Item -->
        <div class="col-md-12">
            <div class="widget-area-2 lochana-box-shadow">
                <h3 class="widget-title"><?php echo $title ?></h3>
                <div class="row no-mp">

                    <div class="col-md-8 offset-md-2">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <tbody>
                                    <tr>
                                        <td><strong>No. Identitas</strong></td>
                                        <td><?php echo $no_id ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Nama Lengkap</strong></td>
                                        <td><?php echo $nama ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Username</strong></td>
                                        <td><b><?php echo $username ?></b></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Jenis Kelamin</strong></td>
                                        <td><?php if ($jk == 'L') {
                                            echo "Laki-laki";
                                        } else { echo "Perempuan";
                                    }?></td>
                                </tr>
                                <tr>
                                    <td><strong>Alamat</strong></td>
                                    <td><?php echo $alamat ?></td>
                                </tr>
                                <tr>
                                    <td><strong>No. Telephone</strong> </td>
                                    <td><?php echo $notelp ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Jabatan</strong> </td>
                                    <td><?php if ($jabatan=='1') {
                                        echo "Admin";
                                    } elseif ($jabatan=='2') {
                                        echo "Dokter/Bidan";
                                    } else {
                                        echo "Petugas Rawat Inap";
                                    }
                                    ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Status</strong></td>
                                    <td><?php echo $status ?></td>
                                </tr>
                            </tbody>
                        </table>
                        <a href="#" onclick="window.history.go(-1)" class="btn btn-sm btn-info"><i class="fa fa-ban"></i> Kembali</a>
                         <a href="<?php echo base_url('pegawai/edit/') ?><?php echo $id_pegawai ?>" class="btn btn-sm btn-warning"><i class="fa fa-pencil"></i> Edit</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- /Widget Item -->
</div>
</div>
			<!-- /Main Content -->