<!-- Page Title -->
<div class="container mt-0">
	<div class="row breadcrumb-bar">
		<div class="col-lg-4">
			<h3 class="block-title"><?php echo $title ?></h3>
		</div>
		<div class="col-lg-8">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="<?php echo base_url() ?>">
						<span class="ti-home"></span>
					</a>
				</li>
				<li class="breadcrumb-item"><?php echo $page ?></li>
				<li class="breadcrumb-item active"><?php echo $title ?></li>
			</ol>
		</div>
	</div>
</div>
<!-- /Page Title -->
<!-- Main Content -->
<div class="container">

	<div class="row">
		<!-- Widget Item -->
		<div class="col-md-12">
			<div class="widget-area-2 lochana-box-shadow">
				<h3 class="widget-title"><?php $title ?></h3>
				<form method="post"	>
					<div class="form-row">
						
						<div class="form-group col-lg-4">
							<label for="dob">No. Identitas</label>
							<input type="text" placeholder="No. Identitas" class="form-control" name="no_id">
						</div>
						<div class="form-group col-lg-4">
							<label for="Doctor-name">Nama Lengkap</label>
							<input type="text" class="form-control" placeholder="Nama Lengkap" name="nama">
						</div>
						<div class="form-group col-lg-4">
							<label for="jeniskelamin">Jenis Kelamin</label>
							<select class="form-control" name="jk">
								<option value="">- Pilih jenis kelamin -</option>
								<option value="L">Laki-laki</option>
								<option value="P">Perempuan</option>
							</select>
						</div>
						<div class="form-group col-lg-4">
							<label for="about-doctor">Alamat</label>
							<textarea placeholder="Alamat Lengkap" class="form-control" name="alamat" rows="3"></textarea>
						</div>
						<div class="form-group col-lg-4">
							<label for="dob">No. Telephone</label>
							<input type="text" placeholder="No. Telephone" class="form-control" name="notelp">
						</div>
						<div class="form-group col-lg-4">
							<label for="jabatan">Jabatan</label>
							<select class="form-control" name="jabatan">
								<option value="1">Admin</option>
								<option value="2">Dokter/Bidan</option>
								<option value="3">Pegawai rawat inap</option>
							</select>
						</div>
						<div class="form-group col-lg-6">
							<label for="dob">Username</label>
							<input type="text" placeholder="Username" class="form-control" name="username">
						</div>
						<div class="form-group col-lg-6">
							<label for="dob">Password</label>
							<input type="password" placeholder="Password" class="form-control" name="password">
						</div>
						
						<div class="form-group col-lg-4 mb-3">
							<button type="submit" name="submit" value="Submit" class="btn btn-primary btn-lg"><i class="fa fa-save"></i> Simpan</button>
							<button type="button" onclick="window.history.go(-1)" class="btn btn-danger btn-lg"><i class="fa fa-ban"></i> Batal</button>
						</div>
					</div>
				</form>
			</div>
		</div>
		<!-- /Widget Item -->
	</div>
</div>