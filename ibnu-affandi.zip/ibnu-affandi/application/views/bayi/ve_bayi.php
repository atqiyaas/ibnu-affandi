<!-- Page Title -->
<div class="container mt-0">
	<div class="row breadcrumb-bar">
		<div class="col-md-6">
			<h3 class="block-title"><?php echo $title ?></h3>
		</div>
		<div class="col-md-6">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="<?php echo base_url() ?>">
						<span class="ti-home"></span>
					</a>
				</li>
				<li class="breadcrumb-item"><?php echo $page ?></li>
				<li class="breadcrumb-item active"><?php echo $title ?></li>
			</ol>
		</div>
	</div>
</div>
<!-- /Page Title -->
<!-- Main Content -->
<div class="container">

	<div class="row">
		<!-- Widget Item -->
		<div class="col-md-12">
			<div class="widget-area-2 lochana-box-shadow">
				<h3 class="widget-title"><?php $title ?></h3>
				<form method="post"	>
					<div class="form-row">
						<div class="formgroup col-md-12 text-center">
							<h3><b>Edit Bayi</h3></b><hr>
						</div>
						<div class="form-group col-md-4">
							<label >ID persalinan</label>
							<input type="text" class="form-control" name="no_id" value="<?php echo $id ?>" readonly>
						</div>
						<div class="form-group col-md-4">
							<label >Nama Bayi</label>
							<input type="text" class="form-control" placeholder="Nama Bayi" name="nama_bayi" value="<?php echo $bayi ?>">
						</div>
						<div class="form-group col-md-4">
							<label >Nama Ibu</label>
							<input type="text" class="form-control" placeholder="Nama Ibu Bayi" name="nama_ibu" value="<?php echo $ibu ?>">
						</div>
						<div class="form-group col-md-4">
							<label >Tanggal Kelahiran Bayi</label>
							<input type="date" class="form-control" placeholder="Tanggal Kelahiran Bayi" name="tgl_lahir_bayi" value="<?php echo $tgl_lahir ?>">
						</div>
						<div class="form-group col-md-4">
							<label>Jenis Persalinan</label>
							<select class="form-control" name="persalinan">
								<option <?php if ($persalinan==='sesar') {
									echo "selected";
								} ?> value="sesar">Sesar</option>
								<option <?php if ($persalinan==='normal') {
									echo "selected";
								} ?>  value="normal">normal</option>
							</select>
						</div>
						<div class="form-group col-md-4">
							<label>Jenis Kelamin</label>
							<select class="form-control" name="jk">
								<option <?php if ($jk=='P') {
									echo "selected";
								} ?> value="P">Perempuan</option>
								<option <?php if ($jk=='L') {
									echo "selected";
								} ?>  value="L">Laki-laki</option>
							</select>
						</div>
												
						<div class="form-group col-md-6 mb-3">
							<button type="submit" name="submit" value="Submit" class="btn btn-primary btn-lg">Update</button>
							<button type="button" onclick="window.history.go(-1)" class="btn btn-danger btn-lg">Batal</button>
						</div>
					</div>
				</form>
			</div>
		</div>
		<!-- /Widget Item -->
	</div>
</div>