<!-- Page Title -->
<div class="container mt-0">
	<div class="row breadcrumb-bar">
		<div class="col-md-6">
			<h3 class="block-title"><?php echo $title ?></h3>
		</div>
		<div class="col-md-6">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="<?php echo base_url() ?>">
						<span class="ti-home"></span>
					</a>
				</li>
				<li class="breadcrumb-item"><?php echo $page ?></li>
				<li class="breadcrumb-item active"><?php echo $title ?></li>
			</ol>
		</div>
	</div>
</div>
<!-- /Page Title -->
<!-- Main Content -->
<div class="container">

	<div class="row">
		<!-- Widget Item -->
		<div class="col-md-12">
			<div class="widget-area-2 lochana-box-shadow bg-warning">
				<h3 class="widget-title"><?php $title ?></h3>
				<form method="post"	>
					<div class="form-row">
						<div class="formgroup col-md-12 text-center">
							<h3><b>Identitas Pasien</h3></b><hr>
						</div>
						<div class="form-group col-md-4">
							<label >No. Identitas</label>
							<input type="text" placeholder="No. Identitas" class="form-control" name="no_id" value="<?php echo $no_id ?>" disabled>
						</div>
						<div class="form-group col-md-4">
							<label >Nama Pasien</label>
							<input type="text" class="form-control" placeholder="Nama Pasien" name="nama" value="<?php echo $nama ?>" disabled>
						</div>
						<div class="form-group col-md-4">
							<label >Nama Suami Pasien</label>
							<input type="text" class="form-control" placeholder="Nama Suami" name="suami" value="<?php echo $suami ?>" disabled>
						</div>
						<div class="form-group col-md-6">
							<label >No. Telephone</label>
							<input type="text" placeholder="No. Telephone" class="form-control" name="notelp" value="<?php echo $notelp ?>"disabled>
						</div>
						<div class="form-group col-md-6">
							<label>Jenis Kelamin</label>
							<select class="form-control" name="jk" disabled="">
								<option <?php if ($jk=='P') {
									echo "selected";
								} ?> value="P">Perempuan</option>
								<option <?php if ($jk=='L') {
									echo "selected";
								} ?>  value="L">Laki-laki</option>
							</select>
						</div>
						<div class="form-group col-md-12">
							<label >Alamat</label>
							<textarea placeholder="Alamat Lengkap" class="form-control" name="alamat" rows="3" disabled><?php echo $alamat ?></textarea>
							<br>
						</div>

						<div class="formgroup col-md-12 text-center">
							<h3><b>Riwayat Pernikahan</b></h3><hr>
						</div>
						<div class="form-group col-md-4">
							<label >Usia Pernikahan <small> (bulan/tahun)</small></label>
							<input type="text" placeholder="Usia Pernikahan" class="form-control" name="usia_nikah">
						</div>
						<div class="form-group col-md-4">
							<label >Jenis KB</label>
							<select class="form-control" name="jkb">
								<option value="">- Pilih jenis KB -</option>
								<option value="S">Spiral</option>
								<option value="P">Pil</option>
							</select>
						</div>
						<div class="form-group col-md-4">
							<label >Lama Pemakaian <small> (bulan/tahun)</small></label>
							<input type="text" placeholder="Lama Pemakaian" class="form-control" name="lama_kb">
						</div>
						<div class="form-group col-md-3">
							<label >Tanggal HPHT</label>
							<input type="date" placeholder="Password" class="form-control" name="hpht">
						</div>
						<div class="form-group col-md-3">
							<label >Tanggal HPL</label>
							<input type="date" class="form-control" name="hpl">
						</div>
						<div class="form-group col-md-3">
							<label >Hamil Ke-</label>
							<input type="number" min="1" class="form-control" name="hamil_ke">
						</div>
						<div class="form-group col-md-3">
							<label >Jumlah anak</label>
							<input type="number" min="1" class="form-control" name="jml_anak">
						</div>
						<div class="form-group col-md-6">
							<label >Riwayat Keguguran</label>
							<select class="form-control" name="riw_keg">
								<option value="Y">Ya</option>
								<option value="T">Tidak</option>
							</select>
						</div>
						<div class="form-group col-md-6">
							<label >Riwayat Persalinan</label>
							<select class="form-control" name="riw_per">
								<option value="Y">Ya</option>
								<option value="T">Tidak</option>
							</select>
						</div>
						<div class="form-group col-md-4">
							<label >Kesehatan Bayi</label>
							<select class="form-control" name="bayi">
								<option value="Y">Ya</option>
								<option value="T">Tidak</option>
							</select>
						</div>
						<div class="form-group col-md-4">
							<label >Berat Badan (Kg)</label>
							<input type="number" min="1" class="form-control" name="berat">
						</div>
						<div class="form-group col-md-4">
							<label >Jenis Persalinan</label>
							<select class="form-control" name="jper">
								<option value="">- Pilih jenis Persalinan -</option>
								<option value="N">Normal</option>
								<option value="S">Sesar</option>
							</select>
						</div>
						<div class="form-group col-md-4">
							<label >Tempat persalinan</label>
							<input type="text" class="form-control" name="tempat_per">
						</div>
						<div class="form-group col-md-4">
							<label >Usia Kehamilan</label>
							<input type="text" class="form-control" name="usia_hamil">
						</div>
						<div class="form-group col-md-4">
							<label >Pernah Hamil ?</label>
							<select class="form-control" name="phamil">
								<option value="Y">Ya</option>
								<option value="T">Tidak</option>
							</select>
						</div>						
						<div class="form-group col-md-6 mb-3">
							<button type="submit" name="submit" value="Submit" class="btn btn-primary btn-lg">Simpan</button>
							<button type="button" onclick="window.history.go(-1)" class="btn btn-danger btn-lg">Batal</button>
						</div>
					</div>
				</form>
			</div>
		</div>
		<!-- /Widget Item -->
	</div>
</div>