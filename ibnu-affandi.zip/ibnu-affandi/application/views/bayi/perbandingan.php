<!-- Page Title -->
<div class="container mt-0">
	<div class="row breadcrumb-bar">
		<div class="col-md-6">
			<h3 class="block-title"><?php echo $title ?></h3>
		</div>
		<div class="col-md-6">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="<?php echo base_url('pasien') ?>">
						<span class="ti-home"> </span><?php echo $page ?> 
					</a>
				</li>
				<li class="breadcrumb-item active"><?php echo $title ?></li>
			</ol>
		</div>
	</div>
</div>
<div class="container">

	<div class="row">
		<!-- Widget Item -->
		
		<div class="col-md-12">
			<div class="widget-area-2 lochana-box-shadow">
				<h3 class="widget-title text-center"><?php echo $title ?></h3>
				<div class="row mb-4">
					<div class="col-md-4">
						<p><strong>No. ID Bayi : <?php echo $id ?></strong></p>
					</div>
					<div class="col-md-4">
						<p class="text-capitalize"><strong>Nama Bayi : <?php echo $bayi ?></strong></p>
					</div>
					<div class="col-md-4">
						<p><strong>Nama Ibu Bayi : <?php echo $ibu ?></strong></p>
					</div>
					<div class="col-md-4">
						<p><strong>Tanggal Lahir : <?php echo date('d F Y', strtotime($tgl_lahir)) ?></strong></p>
					</div>

					<div class="col-md-4">
						<p><strong>Jenis Kelamin : <?php if ($jk==='P') {
							echo "Perempuan";
						} else {
							echo "Laki-laki";
						} ?></strong></p>
					</div>
					<div class="col-md-4">
						<p><strong>Jenis Persalinan : <?php echo $persalinan ?></strong></p>
					</div>
					
				</div>
				<div class="table-responsive mb-3">
					<table class="table table-striped table-hover">
						<tbody class="text-center">
							<tr>
								<th>Tanggal Pemeriksaan</th>
								<td><?php echo $tgl_periksa ?></td>
								<td></td>
								<td><?php echo $tgl_periksa2 ?></td>
								<td></td>
								<td><?php echo $tgl_periksa3 ?></td>
							</tr>
							<tr>
								<th>Berat Badan</th>
								<td><?php echo $bb ?> Ons</td>
								<td><?php if ($bb > $bb2) {
									echo '<i class="fa fa-chevron-right"></i>';
								} elseif ($bb < $bb2) {
									echo '<i class="fa fa-chevron-left"></i>';
								}
								 else {
									echo '<i class="fa fa-exchange"></i>';
								} ?></td>
								<td><?php echo $bb2 ?> Ons</td>
								<td><?php if ($bb2 > $bb3) {
									echo '<i class="fa fa-chevron-right"></i>';
								} elseif ($bb2 < $bb3) {
									echo '<i class="fa fa-chevron-left"></i>';
								}
								 else {
									echo '<i class="fa fa-exchange"></i>';
								} ?></td>
								<td><?php echo $bb3 ?> Ons</td>
							</tr>
							<tr>
								<th>Suhu Badan</th>
								<td><?php echo $suhu ?> <span>&#8451;</span></td>
								<td><?php if ($suhu > $suhu2) {
									echo '<i class="fa fa-chevron-right"></i>';
								} elseif ($suhu < $suhu2) {
									echo '<i class="fa fa-chevron-left"></i>';
								}
								 else {
									echo '<i class="fa fa-exchange"></i>';
								} ?></td>
								<td><?php echo $suhu2 ?> <span>&#8451;</span></td>
								<td><?php if ($suhu2 > $suhu3) {
									echo '<i class="fa fa-chevron-right"></i>';
								} elseif ($suhu2 < $suhu3) {
									echo '<i class="fa fa-chevron-left"></i>';
								}
								 else {
									echo '<i class="fa fa-exchange"></i>';
								} ?></td>
								<td><?php echo $suhu3 ?> <span>&#8451;</span></td>
							</tr>
							<tr>
								<th>Bernafas</th>
								<td><?php echo $bernafas ?></td>
								<td></td>
								<td><?php echo $bernafas2 ?></td>
								<td></td>
								<td><?php echo $bernafas3 ?></td>
							</tr>

							<tr>
								<th>Tonus Otot</th>
								<td><?php echo $otot ?></td>
								<td></td>
								<td><?php echo $otot2 ?></td>
								<td></td>
								<td><?php echo $otot3 ?></td>
							</tr>
							<tr>
								<th>Warna Kulit</th>
								<td><?php echo $kulit ?></td>
								<td></td>
								<td><?php echo $kulit ?></td>
								<td></td>
								<td><?php echo $kulit ?></td>
							</tr>
							<tr>
								<th>Lingkar Kepala</th>
								<td><?php echo $kepala ?></td>
								<td><?php if ($kepala > $kepala2) {
									echo '<i class="fa fa-chevron-right"></i>';
								} elseif ($kepala < $kepala2) {
									echo '<i class="fa fa-chevron-left"></i>';
								}
								 else {
									echo '<i class="fa fa-exchange"></i>';
								} ?></td>
								<td><?php echo $kepala2 ?></td>
								<td><?php if ($kepala2 > $kepala3) {
									echo '<i class="fa fa-chevron-right"></i>';
								} elseif ($kepala2 < $kepala3) {
									echo '<i class="fa fa-chevron-left"></i>';
								}
								 else {
									echo '<i class="fa fa-exchange"></i>';
								} ?></td>
								<td><?php echo $kepala3 ?></td>
							</tr>
							<tr>
								<th>Panjang Badan</th>
								<td><?php echo $panjang ?></td>
								<td><?php if ($panjang > $panjang2) {
									echo '<i class="fa fa-chevron-right"></i>';
								} elseif ($panjang < $panjang2) {
									echo '<i class="fa fa-chevron-left"></i>';
								}
								 else {
									echo '<i class="fa fa-exchange"></i>';
								} ?></td>
								<td><?php echo $panjang2 ?></td>
								<td><?php if ($panjang2 > $panjang3) {
									echo '<i class="fa fa-chevron-right"></i>';
								} elseif ($panjang2 < $panjang3) {
									echo '<i class="fa fa-chevron-left"></i>';
								}
								 else {
									echo '<i class="fa fa-exchange"></i>';
								} ?></td>
								<td><?php echo $panjang3 ?></td>
							</tr>

							<tr>
								<th>Moros</th>
								<td><?php echo $moros ?></td>
								<td></td>
								<td><?php echo $moros2 ?></td>
								<td></td>
								<td><?php echo $moros3 ?></td>
							</tr>
							<tr>
								<th>Lingkar Dada</th>
								<td><?php echo $dada ?></td>
								<td><?php if ($dada > $dada2) {
									echo '<i class="fa fa-chevron-right"></i>';
								} elseif ($dada < $dada2) {
									echo '<i class="fa fa-chevron-left"></i>';
								}
								 else {
									echo '<i class="fa fa-exchange"></i>';
								} ?></td>
								<td><?php echo $dada2 ?></td>
								<td><?php if ($dada2 > $dada3) {
									echo '<i class="fa fa-chevron-right"></i>';
								} elseif ($dada2 < $dada3) {
									echo '<i class="fa fa-chevron-left"></i>';
								}
								 else {
									echo '<i class="fa fa-exchange"></i>';
								} ?></td>
								<td><?php echo $dada3 ?></td>
							</tr>
							<tr>
								<th>Berkedip</th>
								<td><?php echo $berkedip ?></td>
								<td></td>
								<td><?php echo $berkedip2 ?></td>
								<td></td>
								<td><?php echo $berkedip3 ?></td>
							</tr>
							
						</tbody>
					</table>
				</div>
				<hr>
				<div class="col-md-12 mb-5">
					<label>Catatan</label>
					<textarea rows="5" class="form-control"></textarea>
				</div>
			</div>
		</div>
		<!-- /Widget Item -->
	</div>
</div>