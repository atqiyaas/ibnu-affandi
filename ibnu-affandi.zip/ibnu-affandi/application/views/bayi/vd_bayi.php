<div class="container mt-0">
 <div class="row breadcrumb-bar">
  <div class="col-md-6">
    <h3 class="block-title"><?php echo $title ?></h3>
</div>
<div class="col-md-6">
   <ol class="breadcrumb">
    <li class="breadcrumb-item">
     <a href="<?php echo base_url('home') ?>">
      <span class="ti-home"></span>
  </a>
</li>
<li class="breadcrumb-item"><?php echo $page ?></li>
<li class="breadcrumb-item active"><?php echo $title ?></li>
</ol>
</div>
</div>
</div>
<!-- /Page Title -->

<!-- /Breadcrumb -->
<!-- Main Content -->
<div class="container">

    <div class="row">
        <!-- Widget Item -->
        <div class="col-md-12">
            <div class="widget-area-2 lochana-box-shadow">
                <div class="widget-area-2 lochana-box-shadow">
                    <!-- Item -->
                    <h3 class="widget-title">Detail Pemeriksaan <small>Baby</small> <b><?php echo $bayi ?></b> <small>(Anak dari Ny. <?php echo $ibu ?>)</small> </h3>
                    <div class="lochana-widget">
                        <div id="accordion">
                            <div class="card">
                                <div class="accordion-header" id="headingOne">
                                    <h5 class="mb-0" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        Identitas Bayi
                                    </h5>
                                </div>

                                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-6">
                                                <table class="table">
                                                    <tbody>
                                                        <tr>
                                                            <td><strong>Nama Lengkap bayi</strong></td>
                                                            <td class="text-capitalize">: <b><?php echo $bayi ?></b></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Jenis Kelamin</strong></td>
                                                            <td><?php if ($jk == 'L') {
                                                                echo ": <b>Laki-laki</b>";
                                                            } else { echo ": <b>Perempuan</b>";}?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Tanggal lahir bayi</strong></td>
                                                            <td>: <b><?php echo date('d F Y', strtotime($tgl_lahir)) ?></b></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class="col-6">
                                                <table class="table">
                                                    <tbody>
                                                        <tr>
                                                            <td><strong>Nama Ibu</strong></td>
                                                            <td>: <?php echo $ibu ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Jenis Persalinan</strong></td>
                                                            <td class="text-capitalize">: <?php echo $persalinan ?></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="accordion-header" id="headingTwo">
                                    <h5 class="mb-0" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        Kontrol Bayi ke-1
                                    </h5>
                                </div>

                                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                    <div class="card-body">
                                        <div class="lochana-widget">
                                            <div class="bd-example bd-example-tabs">
                                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                                    <?php if ($kontrol1->result() == NULL): ?>
                                                        <li class="nav-item">
                                                            <a class="nav-link">Kontrol Bayi Tidak Ditemukan</a>
                                                        </li>
                                                        <?php else: ?>
                                                            <li class="nav-item">
                                                                <a class="nav-link active show" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false">Pemeriksaan : <small><i>(<?php echo $tgl_periksa ?>)</i></small></a>
                                                            </li>

                                                        <?php endif ?>

                                                    </ul>
                                                    <div class="tab-content" id="myTabContent">
                                                        <?php if ($kontrol1->result() == NULL): ?>
                                                            <div class="tab-pane fade" id="home" role="tabpanel" aria-labelledby="home-tab">
                                                                <?php else: ?>
                                                                    <div class="tab-pane fade active show" id="home" role="tabpanel" aria-labelledby="home-tab">
                                                                    <?php endif ?>
                                                                    <div class="row">
                                                                        <div class="col-6">
                                                                            <table class="table">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td width="49%"><strong>Berat Badan</strong></td>
                                                                                        <td width="2%">:</td>
                                                                                        <td width="49%"><?php echo $bb ?> Ons</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td><strong>Frekuensi Jantung</strong></td>
                                                                                        <td>:</td>
                                                                                        <td><?php echo $jantung ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td><strong>Suhu Badan</strong></td>
                                                                                        <td>:</td>
                                                                                        <td><?php echo $suhu ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td><strong>Usaha Bernafas</strong></td>
                                                                                        <td>:</td>
                                                                                        <td><?php echo $bernafas ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td><strong>Panjang Badan</strong></td>
                                                                                        <td>:</td>
                                                                                        <td><?php echo $panjang ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td><strong>Berkedip</strong></td>
                                                                                        <td>:</td>
                                                                                        <td><?php echo $berkedip ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td><strong>Moros</strong></td>
                                                                                        <td>:</td>
                                                                                        <td><?php echo $moros ?></td>
                                                                                    </tr>

                                                                                </tbody>
                                                                            </table>
                                                                        </div>
                                                                        <div class="col-6">
                                                                            <table class="table">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td width="49%"><strong>Lingkar kepala</strong></td>
                                                                                        <td width="2%">:</td>
                                                                                        <td width="49%"><?php echo $kepala ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td><strong>Lingkar Dada</strong></td>
                                                                                        <td>:</td>
                                                                                        <td><?php echo $dada ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td><strong>Tonus Otot</strong></td>
                                                                                        <td>:</td>
                                                                                        <td><?php echo $otot ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td><strong>Warna Kulit</strong></td>
                                                                                        <td>:</td>
                                                                                        <td><?php echo $kulit ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td><strong>Menggenggam</strong></td>
                                                                                        <td>:</td>
                                                                                        <td><?php echo $menggenggam ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td><strong>Menghisap</strong></td>
                                                                                        <td>:</td>
                                                                                        <td><?php echo $menghisap ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td><strong>Rooting</strong></td>
                                                                                        <td>:</td>
                                                                                        <td><?php echo $rooting ?></td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="card">
                                            <div class="accordion-header" id="headingTiga">
                                                <h5 class="mb-0" data-toggle="collapse" data-target="#collapseTiga" aria-expanded="false" aria-controls="collapseTiga">
                                                    Kontrol Bayi ke-2
                                                </h5>
                                            </div>

                                            <div id="collapseTiga" class="collapse" aria-labelledby="headingTiga" data-parent="#accordion">
                                                <div class="card-body">
                                                    <div class="lochana-widget">
                                                        <div class="bd-example bd-example-tabs">
                                                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                                                <?php if ($kontrol2->result() == NULL): ?>
                                                                    <li class="nav-item">
                                                                        <a class="nav-link">Kontrol Bayi Tidak Ditemukan</a>
                                                                    </li>
                                                                    <?php else: ?>
                                                                        <li class="nav-item">
                                                                            <a class="nav-link active show" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false">Pemeriksaan : <small><i>(<?php echo $tgl_periksa2 ?>)</i></small></a>
                                                                        </li>

                                                                    <?php endif ?>

                                                                </ul>
                                                                <div class="tab-content" id="myTabContent">
                                                                    <?php if ($kontrol2->result() == NULL): ?>
                                                                        <div class="tab-pane fade" id="home" role="tabpanel" aria-labelledby="home-tab">
                                                                            <?php else: ?>
                                                                                <div class="tab-pane fade active show" id="home" role="tabpanel" aria-labelledby="home-tab">
                                                                                <?php endif ?>
                                                                                <div class="row">
                                                                                    <div class="col-6">
                                                                                        <table class="table">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td width="49%"><strong>Berat Badan</strong></td>
                                                                                                    <td width="2%">:</td>
                                                                                                    <td width="49%"><?php echo $bb2 ?> Ons</td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><strong>Frekuensi Jantung</strong></td>
                                                                                                    <td>:</td>
                                                                                                    <td><?php echo $jantung2 ?></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><strong>Suhu Badan</strong></td>
                                                                                                    <td>:</td>
                                                                                                    <td><?php echo $suhu2 ?></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><strong>Usaha Bernafas</strong></td>
                                                                                                    <td>:</td>
                                                                                                    <td><?php echo $bernafas2 ?></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><strong>Panjang Badan</strong></td>
                                                                                                    <td>:</td>
                                                                                                    <td><?php echo $panjang2 ?></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><strong>Berkedip</strong></td>
                                                                                                    <td>:</td>
                                                                                                    <td><?php echo $berkedip2 ?></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><strong>Moros</strong></td>
                                                                                                    <td>:</td>
                                                                                                    <td><?php echo $moros2 ?></td>
                                                                                                </tr>

                                                                                            </tbody>
                                                                                        </table>
                                                                                    </div>
                                                                                    <div class="col-6">
                                                                                        <table class="table">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td width="49%"><strong>Lingkar kepala</strong></td>
                                                                                                    <td width="2%">:</td>
                                                                                                    <td width="49%"><?php echo $kepala2 ?></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><strong>Lingkar Dada</strong></td>
                                                                                                    <td>:</td>
                                                                                                    <td><?php echo $dada2 ?></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><strong>Tonus Otot</strong></td>
                                                                                                    <td>:</td>
                                                                                                    <td><?php echo $otot2 ?></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><strong>Warna Kulit</strong></td>
                                                                                                    <td>:</td>
                                                                                                    <td><?php echo $kulit2 ?></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><strong>Menggenggam</strong></td>
                                                                                                    <td>:</td>
                                                                                                    <td><?php echo $menggenggam2 ?></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><strong>Menghisap</strong></td>
                                                                                                    <td>:</td>
                                                                                                    <td><?php echo $menghisap2 ?></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><strong>Rooting</strong></td>
                                                                                                    <td>:</td>
                                                                                                    <td><?php echo $rooting2 ?></td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="card">
                                                        <div class="accordion-header" id="headingFour">
                                                            <h5 class="mb-0" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                                                Kontrol Bayi ke-3
                                                            </h5>
                                                        </div>

                                                        <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
                                                            <div class="card-body">
                                                                <div class="lochana-widget">
                                                                    <div class="bd-example bd-example-tabs">
                                                                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                                                                            <?php if ($kontrol3->result() == NULL): ?>
                                                                                <li class="nav-item">
                                                                                    <a class="nav-link">Kontrol Bayi Tidak Ditemukan</a>
                                                                                </li>
                                                                                <?php else: ?>
                                                                                    <li class="nav-item">
                                                                                        <a class="nav-link active show" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false">Pemeriksaan : <small><i>(<?php echo $tgl_periksa3 ?>)</i></small></a>
                                                                                    </li>

                                                                                <?php endif ?>

                                                                            </ul>
                                                                            <div class="tab-content" id="myTabContent">
                                                                                <?php if ($kontrol3->result() == NULL): ?>
                                                                                    <div class="tab-pane fade" id="home" role="tabpanel" aria-labelledby="home-tab">
                                                                                        <?php else: ?>
                                                                                            <div class="tab-pane fade active show" id="home" role="tabpanel" aria-labelledby="home-tab">
                                                                                            <?php endif ?>
                                                                                            <div class="row">
                                                                                                <div class="col-6">
                                                                                                    <table class="table">
                                                                                                        <tbody>
                                                                                                            <tr>
                                                                                                                <td width="49%"><strong>Berat Badan</strong></td>
                                                                                                                <td width="2%">:</td>
                                                                                                                <td width="49%"><?php echo $bb3 ?> Ons</td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td><strong>Frekuensi Jantung</strong></td>
                                                                                                                <td>:</td>
                                                                                                                <td><?php echo $jantung3 ?></td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td><strong>Suhu Badan</strong></td>
                                                                                                                <td>:</td>
                                                                                                                <td><?php echo $suhu3 ?></td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td><strong>Usaha Bernafas</strong></td>
                                                                                                                <td>:</td>
                                                                                                                <td><?php echo $bernafas3 ?></td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td><strong>Panjang Badan</strong></td>
                                                                                                                <td>:</td>
                                                                                                                <td><?php echo $panjang3 ?></td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td><strong>Berkedip</strong></td>
                                                                                                                <td>:</td>
                                                                                                                <td><?php echo $berkedip3 ?></td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td><strong>Moros</strong></td>
                                                                                                                <td>:</td>
                                                                                                                <td><?php echo $moros3 ?></td>
                                                                                                            </tr>

                                                                                                        </tbody>
                                                                                                    </table>
                                                                                                </div>
                                                                                                <div class="col-6">
                                                                                                    <table class="table">
                                                                                                        <tbody>
                                                                                                            <tr>
                                                                                                                <td width="49%"><strong>Lingkar kepala</strong></td>
                                                                                                                <td width="2%">:</td>
                                                                                                                <td width="49%"><?php echo $kepala3 ?></td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td><strong>Lingkar Dada</strong></td>
                                                                                                                <td>:</td>
                                                                                                                <td><?php echo $dada3 ?></td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td><strong>Tonus Otot</strong></td>
                                                                                                                <td>:</td>
                                                                                                                <td><?php echo $otot3 ?></td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td><strong>Warna Kulit</strong></td>
                                                                                                                <td>:</td>
                                                                                                                <td><?php echo $kulit3 ?></td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td><strong>Menggenggam</strong></td>
                                                                                                                <td>:</td>
                                                                                                                <td><?php echo $menggenggam3 ?></td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td><strong>Menghisap</strong></td>
                                                                                                                <td>:</td>
                                                                                                                <td><?php echo $menghisap3 ?></td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td><strong>Rooting</strong></td>
                                                                                                                <td>:</td>
                                                                                                                <td><?php echo $rooting3 ?></td>
                                                                                                            </tr>
                                                                                                        </tbody>
                                                                                                    </table>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>

                                                    </div>




                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>