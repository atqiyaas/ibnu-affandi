<!-- Page Title -->
<div class="container mt-0">
	<div class="row breadcrumb-bar">
		<div class="col-lg-4">
			<h3 class="block-title"><?php echo $title ?></h3>
		</div>
		<div class="col-lg-8">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="<?php echo base_url() ?>">
						<span class="ti-home"></span>
					</a>
				</li>
				<li class="breadcrumb-item"><?php echo $page ?></li>
				<li class="breadcrumb-item active"><?php echo $title ?></li>
			</ol>
		</div>
	</div>
</div>
<!-- /Page Title -->
<!-- Main Content -->
<div class="container">

	<div class="row">
		<!-- Widget Item -->
		<div class="col-md-12">
			<div class="widget-area-2 lochana-box-shadow">
				<h3 class="widget-title"><?php $title ?></h3>
				<form method="post"	enctype="multipart/form-data">
					<?= validation_errors(
						'<div class="alert alert-danger alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
						</button>','</div>'); ?>
						<div class="form-row">
							<div class="form-group col-lg-2">
								<label>ID Bayi</label>
								<input type="text" value="<?php echo $id ?>" class="form-control" name="id" readonly>
							</div>
							
							<div class="form-group col-lg-4">
								<label>Nama Bayi <small>(Ny. <?php echo $ibu ?>)</small></label>
								<input type="text" value="<?php echo $bayi ?>" class="form-control text-capitalize" readonly>
							</div>
							<div class="form-group col-lg-4">
								<label>Tanggal Pemeriksaan</label>
								<input type="text" value="<?php echo date('d F Y') ?>" class="form-control" name="tgl_periksa" readonly>
							</div>
							<div class="form-group col-lg-2">
								<label>Pemeriksaan Ke-</label>
								<select class="form-control" name="no_pk" autofocus>
									<option value="pk1">1</option>
									<option value="pk2">2</option>
									<option value="pk3">3</option>
								</select>
							</div>
							<div class="form-group col-lg-4">
								<label>Berat badan bayi (Ons)</label>
								<input type="number" class="form-control" name="bb">
							</div>
							<div class="form-group col-lg-4">
								<label>Frekuensi Jantung</label>
								<input type="text" class="form-control" name="jantung">
							</div>
							<div class="form-group col-lg-4">
								<label>Suhu Badan (<span>&#8451;</span>)</label>
								<input type="text" class="form-control" name="suhu">
							</div>
							<div class="form-group col-lg-4">
								<label>Lingkar Kepala</label>
								<input type="text" class="form-control" name="kepala">
							</div>
							<div class="form-group col-lg-4">
								<label>Panjang Badan (cm)</label>
								<input type="text" class="form-control" name="panjang">
							</div>
							<div class="form-group col-lg-4">
								<label>Lingkar Dada</label>
								<input type="text" class="form-control" name="dada">
							</div>

							<div class="form-group col-lg-3 tl">
								<label>Usaha Bernafas</label>
								<select class="form-control" name="bernafas">
									<option value="Normal">Normal</option>
									<option value="Tidak Normal">Tidak Normal</option>
								</select>
							</div>

							<div class="form-group col-lg-3 tl">
								<label>Berkedip</label>
								<select class="form-control" name="berkedip">
									<option value="Cepat">Cepat</option>
									<option value="Lambat">Lambat</option>
								</select>
							</div>

							<div class="form-group col-lg-3 tl">
								<label>Menggenggam</label>
								<select class="form-control" name="genggam">
									<option value="Lemah">Lemah</option>
									<option value="Kuat">Kuat</option>
								</select>
							</div>

							<div class="form-group col-lg-3 tl">
								<label>Rooting</label>
								<select class="form-control" name="rooting">
									<option value="Bayi Reflek Searah">Bayi Reflek Searah</option>
									<option value="Tidak">Tidak</option>
								</select>
							</div>

							<div class="form-group col-lg-3 tl">
								<label>Warna Kulit</label>
								<select class="form-control" name="kulit">
									<option value="Semua Kemerahan">Semua Kemerahan</option>
									<option value="Pucat">Pucat</option>
									<option value="Kemerahan Atas Biru">Kemerahan Atas Biru</option>
								</select>
							</div>

							<div class="form-group col-lg-3 tl">
								<label>Moros</label>
								<select class="form-control" name="moros">
									<option value="Cepat">Cepat</option>
									<option value="Lambat">Lambat</option>
									<option value="Tidak Ada respon">Tidak Ada respon</option>
								</select>
							</div>

							<div class="form-group col-lg-3 tl">
								<label>Menghisap</label>
								<select class="form-control" name="menghisap">
									<option value="Cepat Kuat">Cepat Kuat</option>
									<option value="Lemah">Lemah</option>
									<option value="Lemah Kuat">Lemah Kuat</option>
								</select>
							</div>

							<div class="form-group col-lg-3 tl">
								<label>Tonus Otot</label>
								<select class="form-control" name="otot">
									<option value="Gerak Aktif">Gerak Aktif</option>
									<option value="Lemah">Lemah</option>
									<option value="Reflek lambat">Reflek lambat</option>
								</select>
							</div>
							
							<div class="form-group col-lg-3 mb-3">
								<button type="submit" name="submit" value="Submit" class="btn btn-primary btn-lg"><i class="fa fa-save"></i> Simpan</button>
								<button type="button" onclick="window.history.go(-1)" class="btn btn-danger btn-lg"><i class="fa fa-ban"></i> Batal</button>
							</div>
						</div>
					</form>
				</div>
			</div>
			<!-- /Widget Item -->
		</div>
	</div>