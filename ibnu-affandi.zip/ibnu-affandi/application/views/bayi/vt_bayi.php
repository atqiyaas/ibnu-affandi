<!-- Page Title -->
<div class="container mt-0">
	<div class="row breadcrumb-bar">
		<div class="col-md-6">
			<h3 class="block-title"><?php echo $title ?></h3>
		</div>
		<div class="col-md-6">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="<?php echo base_url() ?>">
						<span class="ti-home"></span>
					</a>
				</li>
				<li class="breadcrumb-item"><?php echo $page ?></li>
				<li class="breadcrumb-item active"><?php echo $title ?></li>
			</ol>
		</div>
	</div>
</div>
<!-- /Page Title -->
<!-- Main Content -->
<div class="container">

	<div class="row">
		<!-- Widget Item -->
		<div class="col-md-12">
			<div class="widget-area-2 lochana-box-shadow">
				<h3 class="widget-title"><?php $title ?></h3>
				<form method="post"	>
					<div class="form-row">
						<div class="form-group col-md-12 text-center">
							<h3><b>Data Persalinan - Identitas Bayi</h3></b><hr>
						</div>

						<div class="form-group col-md-6 offset-3">
							<label>Nama Ibu (Pasien)</label>
							<select class="form-control" name="nama_ibu">
								<option value="">- Nama Pasien (Ibu) -</option>
								<?php
								foreach ($rawat->result() as $key) :

									?>
									<option value="<?php echo $key->nama_pasien ?>"><?php echo $key->nama_pasien ?></option>
								<?php endforeach; ?>
								</select>
							</div>

							<div class="form-group col-md-5">
								<label >Nama Bayi</label>
								<input type="text" placeholder="Nama Bayi" class="form-control" name="nama_bayi">
							</div>

							<div class="form-group col-md-5">
								<label >Tanggal Kelahiran Bayi</label>
								<input type="date" class="form-control" name="tgl_lahir_bayi">
							</div>

							<div class="form-group col-md-5">
								<label>Jenis Persalinan</label>
								<select class="form-control" name="persalinan">
									<option value="">- Pilih jenis Persalinan -</option>
									<option value="normal">Normal</option>
									<option value="sesar">Sesar</option>
								</select>
							</div>

							<div class="form-group col-md-5">
								<label>Jenis Kelamin BAyi</label>
								<select class="form-control" name="jk">
									<option value="">- Pilih jenis Kelamin -</option>
									<option value="L">Laki-laki</option>
									<option value="P">Perempuan</option>
								</select>
							</div>

							<div class="form-group col-md-12 mb-3">
								<button type="submit" name="submit" value="Submit" class="btn btn-primary btn-lg">Simpan</button>
								<button type="button" onclick="window.history.go(-1)" class="btn btn-danger btn-lg">Batal</button>
							</div>
						</div>
					</form>
				</div>
			</div>
			<!-- /Widget Item -->
		</div>
	</div>