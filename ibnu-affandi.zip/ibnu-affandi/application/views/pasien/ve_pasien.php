<!-- Page Title -->
<div class="container mt-0">
	<div class="row breadcrumb-bar">
		<div class="col-md-6">
			<h3 class="block-title"><?php echo $title ?></h3>
		</div>
		<div class="col-md-6">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="<?php echo base_url() ?>">
						<span class="ti-home"></span>
					</a>
				</li>
				<li class="breadcrumb-item"><?php echo $page ?></li>
				<li class="breadcrumb-item active"><?php echo $title ?></li>
			</ol>
		</div>
	</div>
</div>
<!-- /Page Title -->
<!-- Main Content -->
<div class="container">

	<div class="row">
		<!-- Widget Item -->
		<div class="col-md-12">
			<div class="widget-area-2 lochana-box-shadow bg-warning">
				<h3 class="widget-title"><?php $title ?></h3>
				<form method="post"	>
					<div class="form-row">
						<div class="formgroup col-md-12 text-center">
							<h3><b>Identitas Pasien</h3></b><hr>
						</div>
						<div class="form-group col-md-4">
							<label >No. Identitas</label>
							<input type="text" class="form-control" name="no_id" value="<?php echo $no_id ?>">
						</div>
						<div class="form-group col-md-4">
							<label >Nama Pasien</label>
							<input type="text" class="form-control" name="nama" value="<?php echo $nama ?>">
						</div>
						<div class="form-group col-md-4">
							<label >Nama Suami Pasien</label>
							<input type="text" class="form-control" placeholder="Nama Suami" name="suami" value="<?php echo $suami ?>">
						</div>
						<div class="form-group col-md-6">
							<label >No. Telephone</label>
							<input type="text" placeholder="No. Telephone" class="form-control" name="notelp" value="<?php echo $notelp ?>">
						</div>
						<div class="form-group col-md-6">
							<label>Jenis Kelamin</label>
							<select class="form-control" name="jk">
								<option <?php if ($jk=='P') {
									echo "selected";
								} ?> value="P">Perempuan</option>
								<option <?php if ($jk=='L') {
									echo "selected";
								} ?>  value="L">Laki-laki</option>
							</select>
						</div>
						<div class="form-group col-md-12">
							<label >Alamat</label>
							<textarea placeholder="Alamat Lengkap" class="form-control" name="alamat" rows="3"><?php echo $alamat ?></textarea>
						</div>

						<div class="formgroup col-md-12 text-center">
							<h3><b>Riwayat Pernikahan</b></h3><hr>
						</div>
						<div class="form-group col-md-4">
							<label >Usia Pernikahan</label>
							<input type="text" value="<?php echo $usia_nikah ?>" class="form-control" name="usia_nikah">
						</div>
						<div class="form-group col-md-4">
							<label >Jenis KB</label>
							<select class="form-control" name="jkb">
								<option <?php if ($jk === 'L') {
									echo "selected";
								} ?> value="L">Laki-laki</option>
								<option <?php if ($jk === 'P') {
									echo "selected";
								} ?> value="P">Perempuan</option>
							</select>
						</div>
						<div class="form-group col-md-4">
							<label >Lama Pemakaian</label>
							<input type="text" class="form-control" name="lama_kb" value="<?php echo $lama_kb ?>">
						</div>
						<div class="form-group col-md-3">
							<label >Tanggal HPHT</label>
							<input type="date" class="form-control" name="hpht" value="<?php echo $hpht ?>">
						</div>
						<div class="form-group col-md-3">
							<label >Tanggal HPL</label>
							<input type="date" class="form-control" name="hpl" value="<?php echo $hpl ?>">
						</div>
						<div class="form-group col-md-3">
							<label >Hamil Ke-</label>
							<input type="number" class="form-control" name="hamil_ke" value="<?php echo $hamil_ke ?>" >
						</div>
						<div class="form-group col-md-3">
							<label >Jumlah anak</label>
							<input type="number" class="form-control" name="jml_anak" value="<?php echo $jml_anak ?>">
						</div>
						<div class="form-group col-md-6">
							<label >Riwayat Keguguran</label>
							<select class="form-control" name="rkeguguran">
								<option <?php if ($rkeguguran==='ya') {
									echo "selected";
								} ?> value="ya">Ya</option>
								<option <?php if ($rkeguguran==='tidak') {
									echo "selected";
								} ?> value="tidak">Tidak</option>
							</select>
						</div>
						<div class="form-group col-md-6">
							<label >Riwayat Persalinan</label>
							<input type="text" class="form-control" name="rpersalinan" value="<?php echo $rpersalinan ?>">
						</div>
						<div class="form-group col-md-4">
							<label >Kesehatan Bayi</label>
							<input type="text" class="form-control" name="kbayi" value="<?php echo $kbayi ?>">
						</div>
						<div class="form-group col-md-4">
							<label >Berat Badan (ons)</label>
							<input type="text" class="form-control" name="bbadan" value="<?php echo $bbadan ?>">
						</div>
						<div class="form-group col-md-4">
							<label >Jenis Persalinan</label>
							<input type="text" class="form-control" name="jpersalinan" value="<?php echo $jpersalinan ?>">
						</div>
						
						<div class="form-group col-md-4">
							<label >Usia Kehamilan (bulan)</label>
							<input type="text" class="form-control" name="usia_hamil" value="<?php echo $usia_hamil ?>">
						</div>
						<div class="form-group col-md-4">
							<label >Pernah Hamil ?</label>
							<select class="form-control" name="pernahhamil">
								<option <?php if ($pernahhamil==='ya') {
									echo "selected";
								} ?>  value="ya">Ya</option>
								<option <?php if ($pernahhamil==='tidak') {
									echo "selected";
								} ?> value="tidak">Tidak</option>
							</select>
						</div>						
						<div class="form-group col-md-6 mb-3">
							<button type="submit" name="submit" value="Submit" class="btn btn-primary btn-lg">Update</button>
							<button type="button" onclick="window.history.go(-1)" class="btn btn-danger btn-lg">Batal</button>
						</div>
					</div>
				</form>
			</div>
		</div>
		<!-- /Widget Item -->
	</div>
</div>