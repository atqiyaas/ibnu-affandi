<!-- Page Title -->
<div class="container mt-0">
	<div class="row breadcrumb-bar">
		<div class="col-lg-4">
			<h3 class="block-title"><?php echo $title ?></h3>
		</div>
		<div class="col-lg-8">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="<?php echo base_url() ?>">
						<span class="ti-home"></span>
					</a>
				</li>
				<li class="breadcrumb-item"><?php echo $page ?></li>
				<li class="breadcrumb-item active"><?php echo $title ?></li>
			</ol>
		</div>
	</div>
</div>
<!-- /Page Title -->
<!-- Main Content -->
<div class="container">

	<div class="row">
		<!-- Widget Item -->
		<div class="col-md-12">
			<div class="widget-area-2 lochana-box-shadow">
				<h3 class="widget-title"><?php $title ?></h3>
				<form method="post"	enctype="multipart/form-data">
					<?= validation_errors(
						'<div class="alert alert-danger alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
						</button>','</div>'); ?>
						<div class="form-row">
							<div class="form-group col-lg-3">
								<label>No. Identitas</label>
								<input type="text" value="<?php echo $no_id ?>" class="form-control" name="no_id" disabled>
								<input type="hidden" value="<?php echo $no_pasien ?>" class="form-control" name="no">
							</div>
							
							<div class="form-group col-lg-4">
								<label>Nama Pasien</label>
								<input type="text" value="<?php echo $nama ?>" class="form-control" disabled>
							</div>
							<div class="form-group col-lg-3">
								<label>Tanggal Pemeriksaan</label>
								<input type="text" value="<?php echo date('d F Y') ?>" class="form-control" name="tgl_periksa" disabled>
							</div>
							<div class="form-group col-lg-2">
								<label>Pemeriksaan Ke-</label>
								<select class="form-control" name="no_rk" autofocus>
									<option value="rk1">1</option>
									<option value="rk2">2</option>
									<option value="rk3">3</option>
								</select>
							</div>
							<div class="form-group col-lg-4">
								<label>Kesadaran Pasien</label>
								<input type="text" class="form-control" name="kesadaran">
							</div>
							<div class="form-group col-lg-4">
								<label>Tensi Darah</label>
								<input type="text" class="form-control" name="tensi">
							</div>
							<div class="form-group col-lg-4">
								<label>Denyut Nadi</label>
								<input type="text" class="form-control" name="nadi">
							</div>
							<div class="form-group col-lg-4">
								<label>Suhu Badan <small>(Celsiuc)</small></label>
								<input type="text" class="form-control" name="suhu">
							</div>
							<div class="form-group col-lg-4">
								<label>Keadaan Umum</label>
								<input type="text" class="form-control" name="keadaan">
							</div>
							<div class="form-group col-lg-4">
								<label>Berat Badan <small>(Kg)</small></label>
								<input type="number" min="1" class="form-control" name="bb">
							</div>

							<div class="form-group col-lg-4 mb-3">
								<button type="submit" name="submit" value="Submit" class="btn btn-primary btn-lg"><i class="fa fa-save"></i> Simpan</button>
								<button type="button" onclick="window.history.go(-1)" class="btn btn-danger btn-lg"><i class="fa fa-ban"></i> Batal</button>
							</div>
						</div>
					</form>
				</div>
			</div>
			<!-- /Widget Item -->
		</div>
	</div>