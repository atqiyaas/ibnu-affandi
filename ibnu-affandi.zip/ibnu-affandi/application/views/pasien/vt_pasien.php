<!-- Page Title -->
<div class="container mt-0">
	<div class="row breadcrumb-bar">
		<div class="col-md-6">
			<h3 class="block-title"><?php echo $title ?></h3>
		</div>
		<div class="col-md-6">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="<?php echo base_url() ?>">
						<span class="ti-home"></span>
					</a>
				</li>
				<li class="breadcrumb-item"><?php echo $page ?></li>
				<li class="breadcrumb-item active"><?php echo $title ?></li>
			</ol>
		</div>
	</div>
</div>
<!-- /Page Title -->
<!-- Main Content -->
<div class="container">

	<div class="row">
		<!-- Widget Item -->
		<div class="col-md-12">
			<div class="widget-area-2 lochana-box-shadow">
				<h3 class="widget-title"><?php $title ?></h3>
				<form method="post"	>
					<div class="form-row">
						<div class="form-group col-md-12 text-center">
							<h3><b>Identitas Pasien</h3></b><hr>
						</div>
						<div class="form-group col-md-5">
							<label >No. Identitas</label>
							<input type="text" placeholder="No. Identitas" class="form-control" name="no_id">
							<input type="hidden" name="tgl1" value="<?php echo date('d F Y'); ?>">
						</div>
						<div class="form-group col-md-5">
							<label >Nama Pasien</label>
							<input type="text" class="form-control" placeholder="Nama Pasien" name="nama">
						</div>
						
						<div class="form-group col-md-5">
							<label >No. Telephone</label>
							<input type="text" placeholder="No. Telephone" class="form-control" name="notelp">
						</div>
						<div class="form-group col-md-5">
							<label>Jenis Kelamin</label>
							<select class="form-control" name="jk">
								<option value="P">Perempuan</option>
								<option value="L">Laki-laki</option>
							</select>
						</div>
						<div class="form-group col-md-10">
							<label >Alamat</label>
							<textarea placeholder="Alamat Lengkap" class="form-control" name="alamat" rows="5"></textarea>
						</div>


						<!-- Riwayat Pernikahan -->

						<div class="formgroup col-md-12 text-center mt-5">
							<h3><b>Riwayat Pernikahan</b></h3><hr>
						</div>
						<div class="form-group col-md-3">
							<label >Nama Suami Pasien</label>
							<input type="text" class="form-control" placeholder="Nama Suami" name="suami">
						</div>
						<div class="form-group col-md-3">
							<label >Usia Pernikahan</label>
							<input type="text" placeholder="Usia Pernikahan" class="form-control" name="usia_nikah">
						</div>
						<div class="form-group col-md-3">
							<label >Jenis KB</label>
							<select class="form-control" name="jkb">
								<option value="">- Pilih jenis KB -</option>
								<option value="pil">Pil</option>
								<option value="spiral">Spiral</option>
							</select>
						</div>
						<div class="form-group col-md-3">
							<label >Lama Pemakaian</label>
							<input type="text" placeholder="Lama Pemakaian" class="form-control" name="lama_kb">
						</div>
						<div class="form-group col-md-3">
							<label >Tanggal HPHT</label>
							<input type="date" class="form-control" name="hpht">
						</div>
						<div class="form-group col-md-3">
							<label >Tanggal HPL</label>
							<input type="date" class="form-control" name="hpl">
						</div>
						<div class="form-group col-md-3">
							<label >Hamil Ke-</label>
							<input type="number" min="1" class="form-control" name="hamil_ke">
						</div>
						<div class="form-group col-md-3">
							<label >Jumlah anak</label>
							<input type="number" min="1" class="form-control" name="jml_anak">
						</div>
						<div class="form-group col-md-2">
							<label >Riwayat Keguguran</label>
							<select class="form-control" name="rkeguguran">
								<option value="Y">Ya</option>
								<option value="T">Tidak</option>
							</select>
						</div>
						<div class="form-group col-md-2">
							<label >Riwayat Persalinan</label>
							<select class="form-control" name="rpersalinan">
								<option value="Y">Ya</option>
								<option value="T">Tidak</option>
							</select>
						</div>
						<div class="form-group col-md-3">
							<label >Kesehatan Bayi</label>
							<input type="text" name="kbayi" class="form-control">
						</div>
						<div class="form-group col-md-2">
							<label >Berat Badan (kg)</label>
							<input type="number" class="form-control" name="bbadan">
						</div>
						<div class="form-group col-md-3">
							<label >Jenis Persalinan</label>
							<select class="form-control" name="jpersalinan">
								<option value="">- Pilih jenis Persalinan -</option>
								<option value="bp">Belum Pernah</option>
								<option value="n">Normal</option>
								<option value="s">Sesar</option>
							</select>
						</div>
						<div class="form-group col-md-2">
							<label >Usia Kehamilan (bulan)</label>
							<input type="number" min="1" class="form-control" name="usia_hamil">
						</div>
						<div class="form-group col-md-2">
							<label >Pernah Hamil ?</label>
							<select class="form-control" name="pernahhamil">
								<option value="Y">Ya</option>
								<option value="T">Tidak</option>
							</select>
						</div>						
						<div class="form-group col-md-12 mb-3">
							<button type="submit" name="submit" value="Submit" class="btn btn-primary btn-lg">Simpan</button>
							<button type="button" onclick="window.history.go(-1)" class="btn btn-danger btn-lg">Batal</button>
						</div>
					</div>
				</form>
			</div>
		</div>
		<!-- /Widget Item -->
	</div>
</div>