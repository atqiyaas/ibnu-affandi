<!-- Page Title -->
<div class="container mt-0">
	<div class="row breadcrumb-bar">
		<div class="col-lg-4">
			<h3 class="block-title"><?php echo $title ?></h3>
		</div>
		<div class="col-lg-8">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="<?php echo base_url() ?>">
						<span class="ti-home"></span>
					</a>
				</li>
				<li class="breadcrumb-item"><?php echo $page ?></li>
				<li class="breadcrumb-item active"><?php echo $title ?></li>
			</ol>
		</div>
	</div>
</div>
<!-- /Page Title -->
<!-- Main Content -->
<div class="container">

	<div class="row">
		<!-- Widget Item -->
		<div class="col-md-12">
			<div class="widget-area-2 lochana-box-shadow">
				<h3 class="widget-title"><?php $title ?></h3>
				<form method="post"	enctype="multipart/form-data">
					<?= validation_errors(
						'<div class="alert alert-danger alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
						</button>','</div>'); ?>
						<div class="form-row">
							<div class="form-group col-lg-3">
								<label>No. Identitas</label>
								<input type="text" value="<?php echo $no_id ?>" class="form-control" name="no_id" readonly>
								<input type="hidden" value="<?php echo $no_pasien ?>" class="form-control" name="no">
							</div>
							
							<div class="form-group col-lg-3">
								<label>Nama Pasien</label>
								<input type="text" value="<?php echo $nama ?>" class="form-control" readonly>
							</div>
							<div class="form-group col-lg-3">
								<label>Tanggal Pemeriksaan</label>
								<input type="text" value="<?php echo date('d F Y') ?>" class="form-control" name="tgl_periksa" readonly>
							</div>
							<div class="form-group col-lg-2">
								<label>Pemeriksaan Ke-</label>
								<select class="form-control" name="no_pk" autofocus>
									<option value="pk1">1</option>
									<option value="pk2">2</option>
									<option value="pk3">3</option>
								</select>
							</div>
							<div class="form-group col-lg-4 offset-lg-1">
								<label>Umur Kehamilan</label>
								<input type="text" class="form-control" value="<?php echo $usia_hamil ?>" name="usia_hamil" readonly>
							</div>
							<div class="form-group col-lg-4 offset-lg-1">
								<label>Fundusuteri</label>
								<input type="text" class="form-control" name="fundusuteri">
							</div>
							<div class="form-group col-lg-4 offset-lg-1">
								<label>Bagian Perut Atas</label>
								<input type="text" class="form-control" name="bp_atas">
							</div>
							<div class="form-group col-lg-4 offset-lg-1">
								<label>Bagian Perut Bawah</label>
								<input type="text" class="form-control" name="bp_bawah">
							</div>
							<div class="form-group col-lg-4 offset-lg-1">
								<label>Bagian Perut Kanan</label>
								<input type="text" class="form-control" name="bp_kanan">
							</div>
							<div class="form-group col-lg-4 offset-lg-1">
								<label>Bagian Perut Kiri</label>
								<input type="text" class="form-control" name="bp_kiri">
							</div>
							<div class="form-group col-lg-4 offset-lg-1">
								<label>Bagian Panggul</label>
								<input type="text" class="form-control" name="bp_panggul">
							</div>
							<div class="form-group col-lg-4 offset-lg-1">
								<label>Keterangan Bagian Panggul</label>
								<input type="text" class="form-control" name="k_panggul">
							</div>
							
							<div class="form-group col-lg-4 offset-lg-1 mb-3">
								<button type="submit" name="submit" value="Submit" class="btn btn-primary btn-lg"><i class="fa fa-save"></i> Simpan</button>
								<button type="button" onclick="window.history.go(-1)" class="btn btn-danger btn-lg"><i class="fa fa-ban"></i> Batal</button>
							</div>
						</div>
					</form>
				</div>
			</div>
			<!-- /Widget Item -->
		</div>
	</div>