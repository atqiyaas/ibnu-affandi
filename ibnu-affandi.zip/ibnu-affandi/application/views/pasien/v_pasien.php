<!-- Page Title -->
<div class="container mt-0">
	<div class="row breadcrumb-bar">
		<div class="col-md-6">
			<h3 class="block-title text-capitalize"><?php echo $this->session->userdata('nama'); ?></h3>
		</div>
		<div class="col-md-6">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="index-2.html">
						<span class="ti-home"> </span>Klinik 
					</a>
				</li>
				<li class="breadcrumb-item active"><?php echo $title ?></li>
			</ol>
		</div>
	</div>
</div>
<div class="container">

	<div class="row">
		<!-- Widget Item -->
		<div class="col-md-12">
			<div class="widget-area-2 lochana-box-shadow">
				<h3 class="widget-title text-center"><?php echo $title ?></h3>
				<?php if ($this->session->userdata('hak_akses')==='2'): ?>
					<a href="<?php echo base_url('pasien/tambah') ?>" class="btn btn-md btn-primary"><i class="fa fa-plus"></i> Tambah <?php echo $page ?></a>
				<?php endif ?>
				<?php if ($this->session->userdata('hak_akses')==='1'): ?>
					<a href="<?php echo base_url('pasien/tambah') ?>" class="btn btn-md btn-primary"><i class="fa fa-plus"></i> Tambah <?php echo $page ?></a>
				<?php endif ?>
				
				<div class="table-responsive mb-3">
					<table id="tableId" class="table table-hover table-bordered table-striped">
						<thead class="text-center">
							<tr>
								<th>No.</th>
								<th>No. Identitas</th>
								<th>Nama Lengkap</th>
								<th>Nama Suami</th>
								<th>No. Telephone</th>
								<th>Status</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody class="text-center">
							<?php
							$no = 1;
							foreach ($pasien->result() as $key) :
								?>
								<tr>
									<td><?php echo $no++; ?></td>
									<td><?php echo $key->no_identitas; ?></td>
									<td><?php echo $key->nama; ?></td>
									<td><?php echo $key->nama_suami; ?></td>
									<td><?php echo $key->no_telpon; ?></td>
									<td><?php echo $key->status_pasien; ?></td>
									<td>
										<?php if ($this->session->userdata('hak_akses')==='3'): ?>
											<a href="<?php echo base_url('pasien/perbandingan/') ?><?php echo $key->no_pasien ?>" class="btn btn-sm btn-success"  data-toggle="tooltip" data-placement="top" title="Perbandingan Pemeriksaan Pasien"><i class="fa fa-code"></i></a>

											<a href="<?php echo base_url('pasien/detail/') ?><?php echo $key->no_pasien ?>" class="btn btn-sm btn-info"  data-toggle="tooltip" data-placement="top" title="Detail Pasien"><i class="fa fa-eye"></i></a>
										<?php endif ?>

										<?php if ($this->session->userdata('hak_akses')==='2'): ?>
											<a href="<?php echo base_url('pasien/add_rk/') ?><?php echo $key->no_pasien ?>" class="btn btn-sm btn-danger"  data-toggle="tooltip" data-placement="top" title="Input Riwayat Kesehatan Pasien"><i class="fa fa-heartbeat"></i></a>

											<a href="<?php echo base_url('pasien/add_pk/') ?><?php echo $key->no_pasien ?>" class="btn btn-sm btn-warning"  data-toggle="tooltip" data-placement="top" title="Input Pemeriksaan Kesehatan Pasien"><i class="fa fa-plus"></i></a>

											<a href="<?php echo base_url('pasien/perbandingan/') ?><?php echo $key->no_pasien ?>" class="btn btn-sm btn-success"  data-toggle="tooltip" data-placement="top" title="Perbandingan Pemeriksaan Pasien"><i class="fa fa-code"></i></a>

											<a href="<?php echo base_url('pasien/detail/') ?><?php echo $key->no_pasien ?>" class="btn btn-sm btn-info"  data-toggle="tooltip" data-placement="top" title="Detail Pasien"><i class="fa fa-eye"></i></a>

											<a href="<?php echo base_url('pasien/edit/') ?><?php echo $key->no_pasien ?>" class="btn btn-sm btn-warning"  data-toggle="tooltip" data-placement="top" title="Edit Pasien"><i class="fa fa-pencil"></i></a>

											<a href="<?php echo base_url('pasien/haous/') ?><?php echo $key->no_pasien ?>" class="btn btn-sm btn-danger"  data-toggle="tooltip" data-placement="top" title="Hapus Pasien" onclick="return confirm('Yakin dihapus?')"><i class="fa fa-trash"></i></a>
										<?php endif ?>

										<?php if ($this->session->userdata('hak_akses')==='1'): ?>
											<a href="<?php echo base_url('pasien/add_rk/') ?><?php echo $key->no_pasien ?>" class="btn btn-sm btn-danger"  data-toggle="tooltip" data-placement="top" title="Input Riwayat Kesehatan Pasien"><i class="fa fa-heartbeat"></i></a>

											<a href="<?php echo base_url('pasien/add_pk/') ?><?php echo $key->no_pasien ?>" class="btn btn-sm btn-warning"  data-toggle="tooltip" data-placement="top" title="Input Pemeriksaan Kesehatan Pasien"><i class="fa fa-plus"></i></a>

											<a href="<?php echo base_url('pasien/perbandingan/') ?><?php echo $key->no_pasien ?>" class="btn btn-sm btn-success"  data-toggle="tooltip" data-placement="top" title="Perbandingan Pemeriksaan Pasien"><i class="fa fa-code"></i></a>

											<a href="<?php echo base_url('pasien/detail/') ?><?php echo $key->no_pasien ?>" class="btn btn-sm btn-info"  data-toggle="tooltip" data-placement="top" title="Detail Pasien"><i class="fa fa-eye"></i></a>

											<a href="<?php echo base_url('pasien/edit/') ?><?php echo $key->no_pasien ?>" class="btn btn-sm btn-warning"  data-toggle="tooltip" data-placement="top" title="Edit Pasien"><i class="fa fa-pencil"></i></a>

											<a href="<?php echo base_url('pasien/haous/') ?><?php echo $key->no_pasien ?>" class="btn btn-sm btn-danger"  data-toggle="tooltip" data-placement="top" title="Hapus Pasien" onclick="return confirm('Yakin dihapus?')"><i class="fa fa-trash"></i></a>
										<?php endif ?>
										
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<!-- /Widget Item -->
	</div>
</div>