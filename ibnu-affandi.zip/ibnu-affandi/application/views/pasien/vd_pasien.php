<!-- Page Title -->
<div class="container mt-0">
   <div class="row breadcrumb-bar">
      <div class="col-md-6">
        <h3 class="block-title"><?php echo $title ?></h3>
    </div>
    <div class="col-md-6">
     <ol class="breadcrumb">
        <li class="breadcrumb-item">
           <a href="<?php echo base_url('home') ?>">
              <span class="ti-home"></span>
          </a>
      </li>
      <li class="breadcrumb-item"><?php echo $page ?></li>
      <li class="breadcrumb-item active"><?php echo $title ?></li>
  </ol>
</div>
</div>
</div>
<!-- /Page Title -->

<!-- /Breadcrumb -->
<!-- Main Content -->
<div class="container">

    <div class="row">
        <!-- Widget Item -->
        <div class="col-md-12">
            <div class="widget-area-2 lochana-box-shadow">
                <div class="widget-area-2 lochana-box-shadow">
                    <!-- Item -->
                    <h3 class="widget-title">Data Pemeriksaan dari <b>Ny. <?php echo $nama ?> (Status: <?php echo $status ?>) </b></h3>
                    <div class="lochana-widget">
                        <div id="accordion">
                            <div class="card">
                                <div class="accordion-header" id="headingOne">
                                    <h5 class="mb-0" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        Identitas Pasien
                                    </h5>
                                </div>

                                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-6">
                                                <table class="table">
                                                    <tbody>
                                                        <tr>
                                                            <td><strong>No. Identitas</strong></td>
                                                            <td>: <b><?php echo $no_id ?></b></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Nama Lengkap Pasien</strong></td>
                                                            <td>: <b><?php echo $nama ?></b></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Jenis Kelamin</strong></td>
                                                            <td><?php if ($jk == 'L') {
                                                                echo ": <b>Laki-laki</b>";
                                                            } else { echo ": <b>Perempuan</b>";}?></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class="col-6">
                                                <table class="table">
                                                    <tbody>
                                                        <tr>
                                                            <td><strong>No. Telephone</strong></td>
                                                            <td>: <b><?php echo $notelp ?></b></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Nama Suami</strong></td>
                                                            <td>: <?php echo $suami ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Alamat</strong></td>
                                                            <td>: <?php echo $alamat ?></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="accordion-header" id="headingTwo">
                                    <h5 class="mb-0" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        Pemeriksaan Ke-1
                                    </h5>
                                </div>
                                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                    <div class="card-body">
                                        <div class="lochana-widget">
                                            <div class="bd-example bd-example-tabs">
                                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                                    <?php if ($periksahamil->result() == NULL): ?>
                                                        <li class="nav-item">
                                                            <a class="nav-link">Pemeriksaan Kehamilan Kosong</a>
                                                        </li>
                                                        <?php else: ?>
                                                            <li class="nav-item">
                                                                <a class="nav-link active show" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false">Pemeriksaan Kehamilan</a>
                                                            </li>

                                                        <?php endif ?>

                                                        <?php if ($riwayatkes->result() == NULL): ?>
                                                            <li class="nav-item">
                                                                <a class="nav-link">Riwayat Kesehatan Kosong</a>
                                                            </li>
                                                            <?php else: ?>
                                                                <li class="nav-item">
                                                                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Riwayat Kesehatan</a>
                                                                </li>
                                                            <?php endif ?>


                                                            <li class="nav-item">
                                                                <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="true">Riwayat Pernikahan</a>
                                                            </li>
                                                        </ul>
                                                        <div class="tab-content" id="myTabContent">
                                                            <?php if ($periksahamil->result() == NULL): ?>
                                                                <div class="tab-pane fade" id="home" role="tabpanel" aria-labelledby="home-tab">
                                                                    <?php else: ?>
                                                                        <div class="tab-pane fade active show" id="home" role="tabpanel" aria-labelledby="home-tab">
                                                                        <?php endif ?>
                                                                        <div class="row">
                                                                            <div class="col-6">
                                                                                <table class="table">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td width="49%"><strong>Umur Kehamilan</strong></td>
                                                                                            <td width="2%">:</td>
                                                                                            <td width="49%"><?php echo $umur ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Bagian Perut Atas</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $bpa ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Bagian Perut Bawah</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $bpb ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Bagian Panggul</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $panggul ?></td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                            <div class="col-6">
                                                                                <table class="table">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td width="49%"><strong>Fundusuteri</strong></td>
                                                                                            <td width="2%">:</td>
                                                                                            <td width="49%"><?php echo $fundu ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Bagian Perut Kanan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $bpki ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Bagian Perut Kiri</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $bpka ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Keterangan Bagian Panggul</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $kpanggul ?></td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                                                        <div class="row">
                                                                            <div class="col-6">
                                                                                <table class="table">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td width="49%"><strong>Kesadaran</strong></td>
                                                                                            <td width="2%">:</td>
                                                                                            <td width="49%"><?php echo $kesadaran ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Denyut Nadi</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $nadi ?>  kali/menit</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Keadaan Umum</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $keadaan ?></td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                            <div class="col-6">
                                                                                <table class="table">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td width="49%"><strong>Tensi Darah</strong></td>
                                                                                            <td width="2%">:</td>
                                                                                            <td width="49%"><?php echo $tensi ?> mmHg</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Suhu Badan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $suhu ?> <span>&#8451;</span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Berat Badan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $bb ?> Kg</td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                                                                        <div class="row">
                                                                            <div class="col-6">
                                                                                <table class="table">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td width="49%"><strong>Nama Suami</strong></td>
                                                                                            <td width="2%">:</td>
                                                                                            <td width="49%"><?php echo $suami ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Jenis KB</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $jkb ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Tanggal HPHT</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo date('d-F-Y', strtotime($hpht)) ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Hamil Ke-</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $hamil_ke ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Riwayat Keguguran</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $rkeguguran ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Kesehatan Bayi</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $kbayi ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Jenis persalinan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $jpersalinan ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Usia Kehamilan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $usia_hamil ?> Bulan</td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                            <div class="col-6">
                                                                                <table class="table">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td width="49%"><strong>Usia Pernikahan</strong></td>
                                                                                            <td width="2%">:</td>
                                                                                            <td width="49%"><?php echo $usia_nikah ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Lama Pemakaian</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $lama_kb ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Tanggal HPL</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo date('d F Y', strtotime($hpl)) ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Jumlah Anak</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $jml_anak ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Riwayat Persalinan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $rpersalinan ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Berat Badan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $bbadan ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Tempat Persalinan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $tpersalinan ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Pernah Hamil ?</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $pernahhamil ?></td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card">
                                                <div class="accordion-header" id="headingThree">
                                                    <h5 class="mb-0" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                        Pemeriksaan Ke-2
                                                    </h5>
                                                </div>
                                                <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                                                    <div class="card-body">
                                                        <!-- Tabs Area -->
                                                        <div class="lochana-widget">
                                                            <div class="bd-example bd-example-tabs">
                                                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                                                    <?php if ($periksahamil2->result() == NULL): ?>
                                                                        <li class="nav-item">
                                                                            <a class="nav-link">Pemeriksaan Kehamilan Kosong</a>
                                                                        </li>
                                                                        <?php else: ?>
                                                                            <li class="nav-item">
                                                                                <a class="nav-link active show" id="home-tab" data-toggle="tab" href="#home2" role="tab" aria-controls="home" aria-selected="false">Pemeriksaan Kehamilan</a>
                                                                            </li>

                                                                        <?php endif ?>

                                                                        <?php if ($riwayatkes2->result() == NULL): ?>
                                                                            <li class="nav-item">
                                                                                <a class="nav-link">Riwayat Kesehatan Kosong</a>
                                                                            </li>
                                                                            <?php else: ?>
                                                                                <li class="nav-item">
                                                                                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile2" role="tab" aria-controls="profile" aria-selected="false">Riwayat Kesehatan</a>
                                                                                </li>
                                                                            <?php endif ?>


                                                                            <li class="nav-item">
                                                                                <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact2" role="tab" aria-controls="contact" aria-selected="true">Riwayat Pernikahan</a>
                                                                            </li>
                                                                        </ul>
                                                                        <div class="tab-content" id="myTabContent">
                                                                            <?php if ($periksahamil2->result() == NULL): ?>
                                                                <div class="tab-pane fade" id="home" role="tabpanel" aria-labelledby="home-tab">
                                                                    <?php else: ?>
                                                                        <div class="tab-pane fade active show" id="home2" role="tabpanel" aria-labelledby="home-tab">
                                                                        <?php endif ?>
                                                                                <div class="row">
                                                                            <div class="col-6">
                                                                                <table class="table">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td width="49%"><strong>Umur Kehamilan</strong></td>
                                                                                            <td width="2%">:</td>
                                                                                            <td width="49%"><?php echo $umur2 ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Bagian Perut Atas</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $bpa2 ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Bagian Perut Bawah</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $bpb2 ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Bagian Panggul</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $panggul2 ?></td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                            <div class="col-6">
                                                                                <table class="table">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td width="49%"><strong>Fundusuteri</strong></td>
                                                                                            <td width="2%">:</td>
                                                                                            <td width="49%"><?php echo $fundu2 ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Bagian Perut Kanan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $bpki2 ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Bagian Perut Kiri</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $bpka2 ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Keterangan Bagian Panggul</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $kpanggul2 ?></td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                        </div>
                                                                            </div>
                                                                            <div class="tab-pane fade" id="profile2" role="tabpanel" aria-labelledby="profile-tab2">
                                                                                <div class="row">
                                                                            <div class="col-6">
                                                                                <table class="table">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td width="49%"><strong>Kesadaran</strong></td>
                                                                                            <td width="2%">:</td>
                                                                                            <td width="49%"><?php echo $kesadaran2 ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Denyut Nadi</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $nadi2 ?>  kali/menit</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Keadaan Umum</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $keadaan2 ?></td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                            <div class="col-6">
                                                                                <table class="table">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td width="49%"><strong>Tensi Darah</strong></td>
                                                                                            <td width="2%">:</td>
                                                                                            <td width="49%"><?php echo $tensi2 ?> mmHg</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Suhu Badan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $suhu2 ?> <span>&#8451;</span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Berat Badan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $bb2 ?> Kg</td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                        </div>
                                                                            </div>
                                                                            <div class="tab-pane fade" id="contact2" role="tabpanel2" aria-labelledby="contact-tab2">
                                                                                <div class="row">
                                                                            <div class="col-6">
                                                                                <table class="table">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td width="49%"><strong>Nama Suami</strong></td>
                                                                                            <td width="2%">:</td>
                                                                                            <td width="49%"><?php echo $suami ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Jenis KB</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $jkb ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Tanggal HPHT</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo date('d-F-Y', strtotime($hpht)) ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Hamil Ke-</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $hamil_ke ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Riwayat Keguguran</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $rkeguguran ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Kesehatan Bayi</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $kbayi ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Jenis persalinan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $jpersalinan ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Usia Kehamilan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $usia_hamil ?> Bulan</td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                            <div class="col-6">
                                                                                <table class="table">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td width="49%"><strong>Usia Pernikahan</strong></td>
                                                                                            <td width="2%">:</td>
                                                                                            <td width="49%"><?php echo $usia_nikah ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Lama Pemakaian</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $lama_kb ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Tanggal HPL</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo date('d F Y', strtotime($hpl)) ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Jumlah Anak</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $jml_anak ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Riwayat Persalinan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $rpersalinan ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Berat Badan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $bbadan ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Tempat Persalinan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $tpersalinan ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Pernah Hamil ?</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $pernahhamil ?></td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                        </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <!-- /Tabs Area -->
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card">
                                                        <div class="accordion-header" id="headingFour">
                                                            <h5 class="mb-0" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                                                Pemeriksaan Ke-3
                                                            </h5>
                                                        </div>
                                                        <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
                                                            <div class="card-body">
                                                                <!-- Tabs Area -->
                                                                <div class="lochana-widget">
                                                                    <div class="bd-example bd-example-tabs">
                                                                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                                                                            <?php if ($periksahamil3->result() == NULL): ?>
                                                                        <li class="nav-item">
                                                                            <a class="nav-link">Pemeriksaan Kehamilan Kosong</a>
                                                                        </li>
                                                                        <?php else: ?>
                                                                            <li class="nav-item">
                                                                                <a class="nav-link active show" id="home-tab" data-toggle="tab" href="#home3" role="tab" aria-controls="home" aria-selected="false">Pemeriksaan Kehamilan</a>
                                                                            </li>

                                                                        <?php endif ?>

                                                                        <?php if ($riwayatkes3->result() == NULL): ?>
                                                                            <li class="nav-item">
                                                                                <a class="nav-link">Riwayat Kesehatan Kosong</a>
                                                                            </li>
                                                                            <?php else: ?>
                                                                                <li class="nav-item">
                                                                                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile3" role="tab" aria-controls="profile" aria-selected="false">Riwayat Kesehatan</a>
                                                                                </li>
                                                                            <?php endif ?>

                                                                            <li class="nav-item">
                                                                                <a class="nav-link" id="contact-tab3" data-toggle="tab" href="#contact3" role="tab" aria-controls="contact3" aria-selected="true">Riwayat Pernikahan</a>
                                                                            </li>
                                                                        </ul>
                                                                        <div class="tab-content" id="myTabContent">
                                                                             <?php if ($periksahamil3->result() == NULL): ?>
                                                                <div class="tab-pane fade" id="home" role="tabpanel" aria-labelledby="home-tab">
                                                                    <?php else: ?>
                                                                        <div class="tab-pane fade active show" id="home3" role="tabpanel" aria-labelledby="home-tab">
                                                                        <?php endif ?>
                                                                                <div class="row">
                                                                            <div class="col-6">
                                                                                <table class="table">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td width="49%"><strong>Umur Kehamilan</strong></td>
                                                                                            <td width="2%">:</td>
                                                                                            <td width="49%"><?php echo $umur3 ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Bagian Perut Atas</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $bpa3 ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Bagian Perut Bawah</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $bpb3 ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Bagian Panggul</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $panggul3 ?></td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                            <div class="col-6">
                                                                                <table class="table">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td width="49%"><strong>Fundusuteri</strong></td>
                                                                                            <td width="2%">:</td>
                                                                                            <td width="49%"><?php echo $fundu3 ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Bagian Perut Kanan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $bpki3 ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Bagian Perut Kiri</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $bpka3 ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Keterangan Bagian Panggul</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $kpanggul3 ?></td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                        </div>
                                                                            </div>
                                                                            <div class="tab-pane fade" id="profile3" role="tabpanel" aria-labelledby="profile-tab3">
                                                                                <div class="row">
                                                                            <div class="col-6">
                                                                                <table class="table">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td width="49%"><strong>Kesadaran</strong></td>
                                                                                            <td width="2%">:</td>
                                                                                            <td width="49%"><?php echo $kesadaran3 ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Denyut Nadi</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $nadi3 ?>  kali/menit</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Keadaan Umum</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $keadaan3 ?></td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                            <div class="col-6">
                                                                                <table class="table">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td width="49%"><strong>Tensi Darah</strong></td>
                                                                                            <td width="2%">:</td>
                                                                                            <td width="49%"><?php echo $tensi3 ?> mmHg</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Suhu Badan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $suhu3 ?> <span>&#8451;</span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Berat Badan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $bb3 ?> Kg</td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                        </div>
                                                                            </div>
                                                                            <div class="tab-pane fade" id="contact3" role="tabpanel" aria-labelledby="contact-tab3">
                                                                                <div class="row">
                                                                            <div class="col-6">
                                                                                <table class="table">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td width="49%"><strong>Nama Suami</strong></td>
                                                                                            <td width="2%">:</td>
                                                                                            <td width="49%"><?php echo $suami ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Jenis KB</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $jkb ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Tanggal HPHT</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo date('d-F-Y', strtotime($hpht)) ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Hamil Ke-</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $hamil_ke ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Riwayat Keguguran</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $rkeguguran ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Kesehatan Bayi</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $kbayi ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Jenis persalinan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $jpersalinan ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Usia Kehamilan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $usia_hamil ?> Bulan</td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                            <div class="col-6">
                                                                                <table class="table">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td width="49%"><strong>Usia Pernikahan</strong></td>
                                                                                            <td width="2%">:</td>
                                                                                            <td width="49%"><?php echo $usia_nikah ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Lama Pemakaian</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $lama_kb ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Tanggal HPL</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo date('d F Y', strtotime($hpl)) ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Jumlah Anak</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $jml_anak ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Riwayat Persalinan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $rpersalinan ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Berat Badan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $bbadan ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Tempat Persalinan</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $tpersalinan ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><strong>Pernah Hamil ?</strong></td>
                                                                                            <td>:</td>
                                                                                            <td><?php echo $pernahhamil ?></td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                        </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <!-- /Tabs Area -->
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- /Item -->

                                        </div>

                                    </div>
                                </div>
                                <!-- /Widget Item -->
                            </div>
                        </div>
			<!-- /Main Content -->