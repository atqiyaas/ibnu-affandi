<!-- Page Title -->
<div class="container mt-0">
	<div class="row breadcrumb-bar">
		<div class="col-md-6">
			<h3 class="block-title"><?php echo $title ?></h3>
		</div>
		<div class="col-md-6">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="<?php echo base_url('pasien') ?>">
						<span class="ti-home"> </span><?php echo $page ?> 
					</a>
				</li>
				<li class="breadcrumb-item active"><?php echo $title ?></li>
			</ol>
		</div>
	</div>
</div>
<div class="container">

	<div class="row">
		<!-- Widget Item -->
		
		<div class="col-md-12">
			<div class="widget-area-2 lochana-box-shadow">
				<h3 class="widget-title text-center"><?php echo $title ?></h3>
				<div class="row mb-4">
					<div class="col-md-3">
						<p><strong>No. Pasien : <?php echo $no_pasien ?></strong></p>
					</div>
					<div class="col-md-3">
						<p><strong>Hamil Keberapa : <?php echo $hamil_ke ?></strong></p>
					</div>
					<div class="col-md-3">
						<p><strong>Riwayat Persalinan : <?php echo $rpersalinan ?></strong></p>
					</div>
					<div class="col-md-3">
						<p><strong>Tanggal HPL : <?php echo date('d-m-Y', strtotime($hpl)) ?></strong></p>
					</div>

					<div class="col-md-3">
						<p><strong>Pasien : Ny. <?php echo $nama ?></strong></p>
					</div>
					<div class="col-md-3">
						<p><strong>Riwayat Keguguran : <?php echo $rkeguguran ?></strong></p>
					</div>
					<div class="col-md-3">
						<p><strong>Jenis Persalinan : <?php echo $jpersalinan ?></strong></p>
					</div>
					<div class="col-md-3">
						<p><strong>Tanggal HPHT : <?php echo date('d-m-Y', strtotime($hpht)) ?></strong></p>
					</div>
				</div>
				<div class="table-responsive mb-3">
					<table class="table table-striped table-hover">
						<tbody class="text-left">
							<tr>
								<th>Tanggal Pemeriksaan</th>
								<td><?php echo $tgl1 ?></td>
								<td></td>
								<td><?php echo $tgl2 ?></td>
								<td></td>
								<td><?php echo $tgl3 ?></td>
							</tr>
							<tr>
								<th>Kesadaran</th>
								<td><?php echo $kesadaran ?></td>
								<td></td>
								<td><?php echo $kesadaran2 ?></td>
								<td></td>
								<td><?php echo $kesadaran3 ?></td>
							</tr>
							<tr>
								<th>Tensi Darah</th>
								<td><?php echo $tensi ?> mmHg</td>
								<td><?php if ($tensi > $tensi2) {
									echo '<i class="fa fa-chevron-right"></i>';
								} elseif ($tensi < $tensi2) {
									echo '<i class="fa fa-chevron-left"></i>';
								}
								 else {
									echo '<i class="fa fa-exchange"></i>';
								} ?></td>
								<td><?php echo $tensi2 ?> mmHg</td>
								<td><?php if ($tensi2 > $tensi3) {
									echo '<i class="fa fa-chevron-right"></i>';
								} elseif ($tensi2 < $tensi3) {
									echo '<i class="fa fa-chevron-left"></i>';
								}
								 else {
									echo '<i class="fa fa-exchange"></i>';
								} ?></td>
								<td><?php echo $tensi3 ?> mmHg</td>
							</tr>
							<tr>
								<th>Denyut Nadi</th>
								<td><?php echo $nadi ?> kali/min</td>
								<td><?php if ($nadi > $nadi2) {
									echo '<i class="fa fa-chevron-right"></i>';
								} elseif ($nadi < $nadi2) {
									echo '<i class="fa fa-chevron-left"></i>';
								}
								 else {
									echo '<i class="fa fa-exchange"></i>';
								} ?></td>
								<td><?php echo $nadi2 ?> kali/min</td>
								<td><?php if ($nadi2 > $nadi3) {
									echo '<i class="fa fa-chevron-right"></i>';
								} elseif ($nadi2 < $nadi3) {
									echo '<i class="fa fa-chevron-left"></i>';
								}
								 else {
									echo '<i class="fa fa-exchange"></i>';
								} ?></td>
								<td><?php echo $nadi3 ?> kali/min</td>
							</tr>
							<tr>
								<th>Suhu Badan</th>
								<td><?php echo $suhu ?> <span>&#8451;</span></td>
								<td><?php if ($suhu > $suhu2) {
									echo '<i class="fa fa-chevron-right"></i>';
								} elseif ($suhu < $suhu2) {
									echo '<i class="fa fa-chevron-left"></i>';
								}
								 else {
									echo '<i class="fa fa-exchange"></i>';
								} ?></td>
								<td><?php echo $suhu2 ?> <span>&#8451;</span></td>
								<td><?php if ($suhu2 > $suhu3) {
									echo '<i class="fa fa-chevron-right"></i>';
								} elseif ($suhu2 < $suhu3) {
									echo '<i class="fa fa-chevron-left"></i>';
								}
								 else {
									echo '<i class="fa fa-exchange"></i>';
								} ?></td>
								<td><?php echo $suhu3 ?> <span>&#8451;</span></td>
							</tr>
							<tr>
								<th>Keadaan Umum</th>
								<td><?php echo $keadaan ?></td>
								<td></td>
								<td><?php echo $keadaan2 ?></td>
								<td></td>
								<td><?php echo $keadaan3 ?></td>
							</tr>
							<tr>
								<th>Fundus uteri</th>
								<td><?php echo $fundu ?></td>
								<td><?php if ($fundu > $fundu2) {
									echo '<i class="fa fa-chevron-right"></i>';
								} elseif ($fundu < $fundu2) {
									echo '<i class="fa fa-chevron-left"></i>';
								}
								 else {
									echo '<i class="fa fa-exchange"></i>';
								} ?></td>
								<td><?php echo $fundu2 ?></td>
								<td><?php if ($fundu2 > $fundu3) {
									echo '<i class="fa fa-chevron-right"></i>';
								} elseif ($fundu2 < $fundu3) {
									echo '<i class="fa fa-chevron-left"></i>';
								}
								 else {
									echo '<i class="fa fa-exchange"></i>';
								} ?></td>
								<td><?php echo $fundu3 ?></td>
							</tr>
							<tr>
								<th>Bagian Perut Atas</th>
								<td><?php echo $bpa ?></td>
								<td></td>
								<td><?php echo $bpa2 ?></td>
								<td></td>
								<td><?php echo $bpa3 ?></td>
							</tr>
							<tr>
								<th>Bagian Perut Bawah</th>
								<td><?php echo $bpb ?></td>
								<td></td>
								<td><?php echo $bpb2 ?></td>
								<td></td>
								<td><?php echo $bpb3 ?></td>
							</tr>
							<tr>
								<th>Bagian Perut Kanan</th>
								<td><?php echo $bpka ?></td>
								<td></td>
								<td><?php echo $bpka2 ?></td>
								<td></td>
								<td><?php echo $bpka3 ?></td>
							</tr>
							<tr>
								<th>Bagian Perut Kiri</th>
								<td><?php echo $bpki ?></td>
								<td></td>
								<td><?php echo $bpki2 ?></td>
								<td></td>
								<td><?php echo $bpki3 ?></td>
							</tr>
							<tr>
								<th>Bagian Panggul</th>
								<td><?php echo $panggul ?></td>
								<td></td>
								<td><?php echo $panggul2 ?></td>
								<td></td>
								<td><?php echo $panggul3 ?></td>
							</tr>
						</tbody>
					</table>
				</div>
				<hr>
				<div class="col-md-12 mb-5">
					<label>Catatan</label>
					<textarea rows="5" class="form-control"></textarea>
				</div>
			</div>
		</div>
		<!-- /Widget Item -->
	</div>
</div>