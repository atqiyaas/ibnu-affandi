<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pasien extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('rsia');
	}

	public function cek_login()
	{
		if (!$this->rsia->logged_in()) 
		{
			redirect('login','refresh');
		}
	}
	public function index()
	{
		$this->cek_login();
		
		$data['pasien'] = $this->rsia->get_all('pasien');

		$data['title'] = 'Data Pasien';
		$data['page'] = 'Pasien';
		$this->template->load('temp', 'pasien/v_pasien', $data);
	}

	public function perbandingan()
	{
		$id = $this->uri->segment(3);
		
		if ($this->rsia->get_where('riwayatkesehatan', array('no_pasien' => $id, 'no_rk' => 'rk3' ))->result() == NULL) {
			echo "<script>alert('Belum Ada Data perbandingan, Silahkan lakukan pemeriksaan ke-3 terlebih dulu')</script>";
			redirect('pasien','refresh');
		} else {

			$data['pasien'] = $this->rsia->get_all('pasien');

			$pasien = $this->rsia->get_where('pasien', array('no_pasien' => $id));

			$data['periksahamil'] = $this->rsia->get_where('pemeriksaankehamilan', array('no_pasien' => $id, 'no_pk' => 'pk1'));
			$data['periksahamil2'] = $this->rsia->get_where('pemeriksaankehamilan', array('no_pasien' => $id, 'no_pk' => 'pk2'));
			$data['periksahamil3'] = $this->rsia->get_where('pemeriksaankehamilan', array('no_pasien' => $id, 'no_pk' => 'pk3'));

			$data['riwayatkes'] = $this->rsia->get_where('riwayatkesehatan', array('no_pasien' => $id, 'no_rk' => 'rk1'));
			$data['riwayatkes2'] = $this->rsia->get_where('riwayatkesehatan', array('no_pasien' => $id, 'no_rk' => 'rk2'));
			$data['riwayatkes3'] = $this->rsia->get_where('riwayatkesehatan', array('no_pasien' => $id, 'no_rk' => 'rk3'));


			$periksahamil = $this->rsia->get_where('pemeriksaankehamilan', array('no_pasien' => $id, 'no_pk' => 'pk1'));
			$periksahamil2 = $this->rsia->get_where('pemeriksaankehamilan', array('no_pasien' => $id, 'no_pk' => 'pk2'));
			$periksahamil3 = $this->rsia->get_where('pemeriksaankehamilan', array('no_pasien' => $id, 'no_pk' => 'pk3'));

			$riwayatkes = $this->rsia->get_where('riwayatkesehatan', array('no_pasien' => $id, 'no_rk' => 'rk1' ));
			$riwayatkes2 = $this->rsia->get_where('riwayatkesehatan', array('no_pasien' => $id, 'no_rk' => 'rk2' ));
			$riwayatkes3 = $this->rsia->get_where('riwayatkesehatan', array('no_pasien' => $id, 'no_rk' => 'rk3' ));

			foreach ($periksahamil->result() as $key) {

				$data['umur'] = $key->umur_kehamilan;
				$data['tgl1'] = $key->tanggal_pemeriksaan;
				$data['bpa'] = $key->bagian_perut_atas;
				$data['bpb'] = $key->bagian_perut_bawah;
				$data['bpki'] = $key->bagian_perut_kiri;
				$data['bpka'] = $key->bagian_perut_kanan;
				$data['panggul'] = $key->bagian_panggul;
				$data['fundu'] = $key->fundusuteri;
				$data['kpanggul'] = $key->keterangan_bagian_panggul;
			};

			foreach ($periksahamil2->result() as $key) {

				$data['umur2'] = $key->umur_kehamilan;
				$data['tgl2'] = $key->tanggal_pemeriksaan;
				$data['bpa2'] = $key->bagian_perut_atas;
				$data['bpb2'] = $key->bagian_perut_bawah;
				$data['bpki2'] = $key->bagian_perut_kiri;
				$data['bpka2'] = $key->bagian_perut_kanan;
				$data['panggul2'] = $key->bagian_panggul;
				$data['fundu2'] = $key->fundusuteri;
				$data['kpanggul2'] = $key->keterangan_bagian_panggul;
			};

			foreach ($periksahamil3->result() as $key) {

				$data['umur3'] = $key->umur_kehamilan;
				$data['tgl3'] = $key->tanggal_pemeriksaan;
				$data['bpa3'] = $key->bagian_perut_atas;
				$data['bpb3'] = $key->bagian_perut_bawah;
				$data['bpki3'] = $key->bagian_perut_kiri;
				$data['bpka3'] = $key->bagian_perut_kanan;
				$data['panggul3'] = $key->bagian_panggul;
				$data['fundu3'] = $key->fundusuteri;
				$data['kpanggul3'] = $key->keterangan_bagian_panggul;
			};

			foreach ($riwayatkes->result() as $key) {

				$data['keadaan'] = $key->keadaan_umum;
				$data['kesadaran'] = $key->kesadaran_pasien;
				$data['tensi'] = $key->tensi_darah;
				$data['bb'] = $key->berat_badan;
				$data['nadi'] = $key->denyut_nadi;
				$data['suhu'] = $key->suhu_badan;

			};

			foreach ($riwayatkes2->result() as $key) {

				$data['keadaan2'] = $key->keadaan_umum;
				$data['kesadaran2'] = $key->kesadaran_pasien;
				$data['tensi2'] = $key->tensi_darah;
				$data['bb2'] = $key->berat_badan;
				$data['nadi2'] = $key->denyut_nadi;
				$data['suhu2'] = $key->suhu_badan;

			};

			foreach ($riwayatkes3->result() as $key) {

				$data['keadaan3'] = $key->keadaan_umum;
				$data['kesadaran3'] = $key->kesadaran_pasien;
				$data['tensi3'] = $key->tensi_darah;
				$data['bb3'] = $key->berat_badan;
				$data['nadi3'] = $key->denyut_nadi;
				$data['suhu3'] = $key->suhu_badan;

			};

			foreach ($pasien->result() as $key) {

				$data['no_id'] = $key->no_identitas;
				$data['no_pasien'] = $key->no_pasien;
				$data['nama'] = $key->nama;
				$data['hamil_ke'] = $key->hamil_ke;
				$data['rpersalinan'] = $key->riwayat_persalinan;
				$data['rkeguguran'] = $key->riwayat_persalinan;
				$data['jpersalinan'] = $key->jenis_persalinan;
				$data['hpl'] = $key->tanggal_hpl;
				$data['hpht'] = $key->tanggal_hpht;
			}

			$data['title'] = 'Perbandingan Pemeriksaan Kehamilan';
			$data['page'] = 'Pasien';
			$this->template->load('temp', 'pasien/perbandingan', $data);
		}
		
	}


	public function tambah()
	{
		if ($this->input->post('submit', TRUE) == 'Submit') {
			#validasi
			$this->form_validation->set_rules('no_id', 'No. identitas', 'required');
			$this->form_validation->set_rules('nama', 'Nama Lengkap', 'required');
			$this->form_validation->set_rules('notelp', 'No. Telephone', 'numeric|required');
			$this->form_validation->set_rules('jk', 'Jenis Kelamin', 'required');
			$this->form_validation->set_rules('alamat', 'Alamat', 'required');

			$this->form_validation->set_rules('suami', 'Username', 'required');
			$this->form_validation->set_rules('usia_nikah', 'Usia Pernikahan', 'required');
			$this->form_validation->set_rules('jkb', 'Jenid KB', 'required');
			$this->form_validation->set_rules('lama_kb', 'Lama Pemakaian KB', 'required');
			$this->form_validation->set_rules('hpht', 'Tanggal HPHT', 'required');
			$this->form_validation->set_rules('hpl', 'Tanggal HPL', 'required');
			$this->form_validation->set_rules('hamil_ke', 'Hamil Ke- Berapa', 'required');
			$this->form_validation->set_rules('jml_anak', 'Jumlah anak', 'required');
			$this->form_validation->set_rules('rkeguguran', 'Riwayat Keguguran', 'required');
			$this->form_validation->set_rules('rpersalinan', 'Riwayat Persalinan', 'required');
			$this->form_validation->set_rules('kbayi', 'Kesehatan Bayi', 'required');
			$this->form_validation->set_rules('bbadan', 'Berat Badan', 'required');
			$this->form_validation->set_rules('jpersalinan', 'Jenis persalinan', 'required');
			$this->form_validation->set_rules('usia_hamil', 'Usia Kehamilan', 'required');
			$this->form_validation->set_rules('pernahhamil', 'Apakah pasien pernah hamil sebelumnya ?', 'required');

			if ($this->form_validation->run() == TRUE) {

				$data = array(
					'no_identitas' => $this->input->post('no_id', TRUE),
					'nama' => $this->input->post('nama', TRUE),
					'jenis_kelamin' => $this->input->post('jk', TRUE),
					'no_telpon' => $this->input->post('notelp', TRUE),
					'alamat' => $this->input->post('alamat', TRUE),

					'nama_suami' => $this->input->post('suami', TRUE),
					'usia_pernikahan' => $this->input->post('usia_nikah', TRUE),
					'jenis_kb' => $this->input->post('jkb', TRUE),
					'lama_pemakaian' => $this->input->post('lama_kb', TRUE),
					'tanggal_hpht' => $this->input->post('hpht', TRUE),
					'tanggal_hpl' => $this->input->post('hpl', TRUE),
					'hamil_ke' => $this->input->post('hamil_ke', TRUE),
					'jumlah_anak' => $this->input->post('jml_anak', TRUE),
					'riwayat_keguguran' => $this->input->post('rkeguguran', TRUE),
					'riwayat_persalinan' => $this->input->post('rpersalinan', TRUE),
					'kesehatan_bayi' => $this->input->post('kbayi', TRUE),
					'berat_badan' => $this->input->post('bbadan', TRUE),
					'jenis_persalinan' => $this->input->post('jpersalinan', TRUE),
					'usia_kehamilan' => $this->input->post('usia_hamil', TRUE),
					'pernah_hamil' => $this->input->post('pernahhamil', TRUE),
					'tgl1' => $this->input->post('tgl1', TRUE),
				);
				

				$this->rsia->insert('pasien', $data);
				echo "<script>alert('Data pasien berhasil ditambah')</script>";
				redirect('pasien','refresh');

			} 
		}
		
		$data['title'] = 'Tambah Pasien';
		$data['page'] = 'Pasien';
		$this->template->load('temp', 'pasien/vt_pasien', $data);
	}

	/* tambah data riwayat kesehatan */

	public function add_rk()
	{
		$id = $this->uri->segment(3);

		if ($this->input->post('submit', TRUE) == 'Submit') {
			#validasi
			$this->form_validation->set_rules('no', 'Nomor pasien', 'required');
			// $this->form_validation->set_rules('tgl_periksa', 'Tanggal Pemeriksaan', 'required');
			$this->form_validation->set_rules('no_rk', 'Pemeriksaan Ke-', 'required');
			$this->form_validation->set_rules('kesadaran', 'Kesadaran Pasien', 'required');
			$this->form_validation->set_rules('tensi', 'Tensi Darah', 'required');
			$this->form_validation->set_rules('nadi', 'Denyut Nadi', 'required');
			$this->form_validation->set_rules('suhu', 'Suhu Badan', 'required');
			$this->form_validation->set_rules('keadaan', 'Keadaan Umum', 'required');
			$this->form_validation->set_rules('bb', 'Berat Badan', 'required');

			if ($this->form_validation->run() == TRUE) {

				$data = array(
					'no_pasien' => $this->input->post('no', TRUE),
					'tanggal_pemeriksaan' => date('d F Y'),
					'no_rk' => $this->input->post('no_rk', TRUE),
					'kesadaran_pasien' => $this->input->post('kesadaran', TRUE),
					'keadaan_umum' => $this->input->post('keadaan', TRUE),
					'tensi_darah' => $this->input->post('tensi', TRUE),
					'denyut_nadi' => $this->input->post('nadi', TRUE),
					'suhu_badan' => $this->input->post('suhu', TRUE),
					'berat_badan' => $this->input->post('bb', TRUE),
				);
				

				$this->rsia->insert('riwayatkesehatan', $data);
				echo "<script>alert('Data riwayat kesahatan berhasil ditambah')</script>";
				redirect('pasien','refresh');

			} 
		}
		$pasien = $this->rsia->get_where('pasien', array('no_pasien' => $id));

		foreach ($pasien->result() as $key) {

			$data['no_id'] = $key->no_identitas;
			$data['no_pasien'] = $key->no_pasien;
			$data['nama'] = $key->nama;
		}		
		
		$data['title'] = 'Input Riwayat Kesehatan';
		$data['page'] = 'Pasien';
		$this->template->load('temp', 'pasien/add_rkesehatan', $data);
	}

	/*end of tambah data riwayat kesehatan*/

	/* tambah data Pemeriksaan Kehamilan*/

	public function add_pk()
	{
		$id = $this->uri->segment(3);

		if ($this->input->post('submit', TRUE) == 'Submit') {
			#validasi
			$this->form_validation->set_rules('no', 'Nomor pasien', 'required');
			$this->form_validation->set_rules('usia_hamil', 'Usia Kehamilan', 'required');
			$this->form_validation->set_rules('fundusuteri', '', 'required');
			$this->form_validation->set_rules('bp_atas', 'Bagian Perut Atas', 'required');
			$this->form_validation->set_rules('bp_bawah', 'Bagian Perut Bawah', 'required');
			$this->form_validation->set_rules('bp_kanan', 'Bagian Perut Kanan', 'required');
			$this->form_validation->set_rules('bp_kiri', 'Bagian Perut Kiri', 'required');
			$this->form_validation->set_rules('bp_panggul', 'Bagian Panggul', 'required');
			$this->form_validation->set_rules('k_panggul', 'Keterangan Bagian Panggul', 'required');
			

			if ($this->form_validation->run() == TRUE) {

				$data = array(
					'no_pasien' => $this->input->post('no', TRUE),
					'no_pk' => $this->input->post('no_pk', TRUE),
					'tanggal_pemeriksaan' => $this->input->post('tgl_periksa', TRUE),
					'umur_kehamilan' => $this->input->post('usia_hamil', TRUE),
					'fundusuteri' => $this->input->post('fundusuteri', TRUE),
					'bagian_perut_atas' => $this->input->post('bp_atas', TRUE),
					'bagian_perut_bawah' => $this->input->post('bp_bawah', TRUE),
					'bagian_perut_kanan' => $this->input->post('bp_kanan', TRUE),
					'bagian_perut_kiri' => $this->input->post('bp_kiri', TRUE),
					'bagian_panggul' => $this->input->post('bp_panggul', TRUE),
					'keterangan_bagian_panggul' => $this->input->post('k_panggul', TRUE),
					// 'tanggal_pemeriksaan' => date('d F Y'),
					
				);
				

				$this->rsia->insert('pemeriksaankehamilan', $data);
				echo "<script>alert('Data periksaan berhasil ditambah')</script>";
				redirect('pasien','refresh');

			} 
		}
		$pasien = $this->rsia->get_where('pasien', array('no_pasien' => $id));

		foreach ($pasien->result() as $key) {

			$data['no_id'] = $key->no_identitas;
			$data['no_pasien'] = $key->no_pasien;
			$data['nama'] = $key->nama;
			$data['usia_hamil'] = $key->usia_kehamilan;
		}		
		
		$data['title'] = 'Input Pemeriksaan Kehamilan';
		$data['page'] = 'Pasien';
		$this->template->load('temp', 'pasien/add_pkehamilan', $data);
	}

	/*end of tambah data Pemeriksaan Kehamilan*/

	public function edit()
	{
		$id = $this->uri->segment(3);

		if ($this->input->post('submit', TRUE) == 'Submit') {

			$this->form_validation->set_rules('no_id', 'No. identitas', 'required');
			$this->form_validation->set_rules('nama', 'Nama Lengkap', 'required');
			$this->form_validation->set_rules('jk', 'Jenis Kelamin', 'required');
			$this->form_validation->set_rules('notelp', 'No. Telephone', 'required');
			$this->form_validation->set_rules('alamat', 'Alamat', 'required');

			$this->form_validation->set_rules('suami', 'Nama Suami', 'required');
			$this->form_validation->set_rules('usia_nikah', 'Usia Pernikahan', 'required');
			$this->form_validation->set_rules('jkb', 'Jenid KB', 'required');
			$this->form_validation->set_rules('lama_kb', 'Lama Pemakaian KB', 'required');
			$this->form_validation->set_rules('hpht', 'Tanggal HPHT', 'required');
			$this->form_validation->set_rules('hpl', 'Tanggal HPL', 'required');
			$this->form_validation->set_rules('hamil_ke', 'Hamil Ke- Berapa', 'required');
			$this->form_validation->set_rules('jml_anak', 'Jumlah anak', 'required');
			$this->form_validation->set_rules('rkeguguran', 'Riwayat Keguguran', 'required');
			$this->form_validation->set_rules('rpersalinan', 'Riwayat Persalinan', 'required');
			$this->form_validation->set_rules('kbayi', 'Kesehatan Bayi', 'required');
			$this->form_validation->set_rules('bbadan', 'Berat Badan', 'required');
			$this->form_validation->set_rules('jpersalinan', 'Jenis persalinan', 'required');
			$this->form_validation->set_rules('usia_hamil', 'Usia Kehamilan', 'required');
			$this->form_validation->set_rules('pernahhamil', 'Apakah pasien pernah hamil sebelumnya ?', 'required');

			if ($this->form_validation->run() == TRUE) {

				
				$update = array(
					'no_identitas' => $this->input->post('no_id', TRUE),
					'nama' => $this->input->post('nama', TRUE),
					'jenis_kelamin' => $this->input->post('jk', TRUE),
					'no_telpon' => $this->input->post('notelp', TRUE),
					'alamat' => $this->input->post('alamat', TRUE),

					'nama_suami' => $this->input->post('suami', TRUE),
					'usia_pernikahan' => $this->input->post('usia_nikah', TRUE),
					'jenis_kb' => $this->input->post('jkb', TRUE),
					'lama_pemakaian' => $this->input->post('lama_kb', TRUE),
					'tanggal_hpht' => $this->input->post('hpht', TRUE),
					'tanggal_hpl' => $this->input->post('hpl', TRUE),
					'hamil_ke' => $this->input->post('hamil_ke', TRUE),
					'jumlah_anak' => $this->input->post('jml_anak', TRUE),
					'riwayat_keguguran' => $this->input->post('rkeguguran', TRUE),
					'riwayat_persalinan' => $this->input->post('rpersalinan', TRUE),
					'kesehatan_bayi' => $this->input->post('kbayi', TRUE),
					'berat_badan' => $this->input->post('bbadan', TRUE),
					'jenis_persalinan' => $this->input->post('jpersalinan', TRUE),
					'usia_kehamilan' => $this->input->post('usia_hamil', TRUE),
					'pernah_hamil' => $this->input->post('pernahhamil', TRUE),
				);
				$this->rsia->update('pasien', $update, array('no_pasien' => $id));
				echo "<script>alert('Data pasien berhasil diupdate')</script>;";
				redirect('pasien','refresh');

			} 
		}

		$pasien = $this->rsia->get_where('pasien', array('no_pasien' => $id));

		foreach ($pasien->result() as $key) {

			$data['no_id'] = $key->no_identitas;
			$data['nama'] = $key->nama;
			$data['notelp'] = $key->no_telpon;
			$data['jk'] = $key->jenis_kelamin;
			$data['status'] = $key->status_pasien;
			$data['alamat'] = $key->alamat;

			$data['suami'] = $key->nama_suami;
			$data['usia_nikah'] = $key->usia_pernikahan;
			$data['jkb'] = $key->jenis_kb;
			$data['lama_kb'] = $key->lama_pemakaian;
			$data['hpht'] = $key->tanggal_hpht;
			$data['hpl'] = $key->tanggal_hpl;
			$data['hamil_ke'] = $key->hamil_ke;
			$data['jml_anak'] = $key->jumlah_anak;
			$data['rkeguguran'] = $key->riwayat_keguguran;
			$data['rpersalinan'] = $key->riwayat_persalinan;
			$data['kbayi'] = $key->kesehatan_bayi;
			$data['bbadan'] = $key->berat_badan;
			$data['jpersalinan'] = $key->jenis_persalinan;
			$data['usia_hamil'] = $key->usia_kehamilan;
			$data['pernahhamil'] = $key->pernah_hamil;
		};		

		$data['title'] = 'Edit pasien';

		$data['page'] = 'pasien';
		$this->template->load('temp', 'pasien/ve_pasien', $data);	
	}
	public function proses()
	{
		$id = $this->uri->segment(3);

		if ($this->input->post('submit', TRUE) == 'Submit') {

			$this->form_validation->set_rules('usia_nikah', 'Usia Pernikahan', 'required');
			$this->form_validation->set_rules('jkb', 'Jenis KB', 'required');
			$this->form_validation->set_rules('lama_kb', 'Lama Pemakaian', 'required');
			$this->form_validation->set_rules('hpht', 'Tanggal HPHT', 'required');
			$this->form_validation->set_rules('hpl', 'Tanggal HPL', 'required');
			$this->form_validation->set_rules('hamil_ke', 'Hamil Ke-', 'required');
			$this->form_validation->set_rules('jml_anak', 'Jumlah anak', 'required');
			$this->form_validation->set_rules('riw_keg', 'Riwayat Keguguran', 'required');
			$this->form_validation->set_rules('riw_per', 'Riwayat Persalinan', 'required');
			$this->form_validation->set_rules('bayi', 'Kesehatan Bayi', 'required');
			$this->form_validation->set_rules('berat', 'Berat Badan', 'required');
			$this->form_validation->set_rules('jper', 'jenis persalinan', 'required');
			$this->form_validation->set_rules('tempat_per', 'Tempat persalinan', 'required');
			$this->form_validation->set_rules('usia_hamil', 'Usia Kehamilan', 'required');
			$this->form_validation->set_rules('phamil', 'Pernah Hamil?', 'required');

			if ($this->form_validation->run() == TRUE) {

				
				$update = array(
					'usia_pernikahan' => $this->input->post('usia_nikah', TRUE),
					'jenis_kb' => $this->input->post('jkb', TRUE),
					'lama_pemakaian' => $this->input->post('lama_kb', TRUE),
					'tanggal_hpht' => $this->input->post('hpht', TRUE),
					'tanggal_hpl' => $this->input->post('hpl', TRUE),
					'hamil_ke' => $this->input->post('hamil_ke', TRUE),
					'jumlah_anak' => $this->input->post('jml_anak', TRUE),
					'riwayat_keguguran' => $this->input->post('riw_keg', TRUE),
					'riwayat_persalinan' => $this->input->post('riw_per', TRUE),
					'kesehatan_bayi' => $this->input->post('bayi', TRUE),
					'berat_badan' => $this->input->post('berat', TRUE),
					'jenis_persalinan' => $this->input->post('jper', TRUE),
					'tempat_persalinan' => $this->input->post('tempat_per', TRUE),
					'usia_kehamilan' => $this->input->post('usia_hamil', TRUE),
					'pernah_hamil' => $this->input->post('phamil', TRUE),
				);
				$this->rsia->update('pasien', $update, array('no_pasien' => $id));
				echo "<script>alert('Data pasien berhasil diupdate')</script>;";
				redirect('pasien','refresh');

			} 
		}

		$pasien = $this->rsia->get_where('pasien', array('no_pasien' => $id));

		foreach ($pasien->result() as $key) {

			$data['no_id'] = $key->no_identitas;
			$data['nama'] = $key->nama;
			$data['suami'] = $key->nama_suami;
			$data['notelp'] = $key->no_telpon;
			$data['jk'] = $key->jenis_kelamin;
			$data['status'] = $key->status_pasien;
			$data['alamat'] = $key->alamat;
		}		

		$data['title'] = 'Edit pasien';
		$data['page'] = 'pasien';
		$this->template->load('temp', 'pasien/vp_pasien', $data);	
	}

	function detail()
	{
		$id = $this->uri->segment(3);

		$pasien = $this->rsia->get_where('pasien', array('no_pasien' => $id));

		foreach ($pasien->result() as $key) {

			$data['id'] = $key->no_pasien;
			$data['no_id'] = $key->no_identitas;
			$data['nama'] = $key->nama;
			$data['notelp'] = $key->no_telpon;
			$data['jk'] = $key->jenis_kelamin;
			$data['status'] = $key->status_pasien;
			$data['alamat'] = $key->alamat;

			$data['suami'] = $key->nama_suami;
			$data['usia_nikah'] = $key->usia_pernikahan;
			$data['jkb'] = $key->jenis_kb;
			$data['lama_kb'] = $key->lama_pemakaian;
			$data['hpht'] = $key->tanggal_hpht;
			$data['hpl'] = $key->tanggal_hpl;
			$data['hamil_ke'] = $key->hamil_ke;
			$data['jml_anak'] = $key->jumlah_anak;
			$data['rkeguguran'] = $key->riwayat_keguguran;
			$data['rpersalinan'] = $key->riwayat_persalinan;
			$data['kbayi'] = $key->kesehatan_bayi;
			$data['bbadan'] = $key->berat_badan;
			$data['jpersalinan'] = $key->jenis_persalinan;
			$data['usia_hamil'] = $key->usia_kehamilan;
			$data['pernahhamil'] = $key->pernah_hamil;
		};

		$data['periksahamil'] = $this->rsia->get_where('pemeriksaankehamilan', array('no_pasien' => $id, 'no_pk' => 'pk1'));
		$data['periksahamil2'] = $this->rsia->get_where('pemeriksaankehamilan', array('no_pasien' => $id, 'no_pk' => 'pk2'));
		$data['periksahamil3'] = $this->rsia->get_where('pemeriksaankehamilan', array('no_pasien' => $id, 'no_pk' => 'pk3'));

		$data['riwayatkes'] = $this->rsia->get_where('riwayatkesehatan', array('no_pasien' => $id, 'no_rk' => 'rk1'));
		$data['riwayatkes2'] = $this->rsia->get_where('riwayatkesehatan', array('no_pasien' => $id, 'no_rk' => 'rk2'));
		$data['riwayatkes3'] = $this->rsia->get_where('riwayatkesehatan', array('no_pasien' => $id, 'no_rk' => 'rk3'));


		$periksahamil = $this->rsia->get_where('pemeriksaankehamilan', array('no_pasien' => $id, 'no_pk' => 'pk1'));
		$periksahamil2 = $this->rsia->get_where('pemeriksaankehamilan', array('no_pasien' => $id, 'no_pk' => 'pk2'));
		$periksahamil3 = $this->rsia->get_where('pemeriksaankehamilan', array('no_pasien' => $id, 'no_pk' => 'pk3'));

		$riwayatkes = $this->rsia->get_where('riwayatkesehatan', array('no_pasien' => $id, 'no_rk' => 'rk1' ));
		$riwayatkes2 = $this->rsia->get_where('riwayatkesehatan', array('no_pasien' => $id, 'no_rk' => 'rk2' ));
		$riwayatkes3 = $this->rsia->get_where('riwayatkesehatan', array('no_pasien' => $id, 'no_rk' => 'rk3' ));

		foreach ($periksahamil->result() as $key) {

			$data['umur'] = $key->umur_kehamilan;
			$data['bpa'] = $key->bagian_perut_atas;
			$data['bpb'] = $key->bagian_perut_bawah;
			$data['bpki'] = $key->bagian_perut_kiri;
			$data['bpka'] = $key->bagian_perut_kanan;
			$data['panggul'] = $key->bagian_panggul;
			$data['fundu'] = $key->fundusuteri;
			$data['kpanggul'] = $key->keterangan_bagian_panggul;
		};

		foreach ($periksahamil2->result() as $key) {

			$data['umur2'] = $key->umur_kehamilan;
			$data['bpa2'] = $key->bagian_perut_atas;
			$data['bpb2'] = $key->bagian_perut_bawah;
			$data['bpki2'] = $key->bagian_perut_kiri;
			$data['bpka2'] = $key->bagian_perut_kanan;
			$data['panggul2'] = $key->bagian_panggul;
			$data['fundu2'] = $key->fundusuteri;
			$data['kpanggul2'] = $key->keterangan_bagian_panggul;
		};

		foreach ($periksahamil3->result() as $key) {

			$data['umur3'] = $key->umur_kehamilan;
			$data['bpa3'] = $key->bagian_perut_atas;
			$data['bpb3'] = $key->bagian_perut_bawah;
			$data['bpki3'] = $key->bagian_perut_kiri;
			$data['bpka3'] = $key->bagian_perut_kanan;
			$data['panggul3'] = $key->bagian_panggul;
			$data['fundu3'] = $key->fundusuteri;
			$data['kpanggul3'] = $key->keterangan_bagian_panggul;
		};

		foreach ($riwayatkes->result() as $key) {

			$data['keadaan'] = $key->keadaan_umum;
			$data['kesadaran'] = $key->kesadaran_pasien;
			$data['tensi'] = $key->tensi_darah;
			$data['bb'] = $key->berat_badan;
			$data['nadi'] = $key->denyut_nadi;
			$data['suhu'] = $key->suhu_badan;
			
		};

		foreach ($riwayatkes2->result() as $key) {

			$data['keadaan2'] = $key->keadaan_umum;
			$data['kesadaran2'] = $key->kesadaran_pasien;
			$data['tensi2'] = $key->tensi_darah;
			$data['bb2'] = $key->berat_badan;
			$data['nadi2'] = $key->denyut_nadi;
			$data['suhu2'] = $key->suhu_badan;
			
		};

		foreach ($riwayatkes3->result() as $key) {

			$data['keadaan3'] = $key->keadaan_umum;
			$data['kesadaran3'] = $key->kesadaran_pasien;
			$data['tensi3'] = $key->tensi_darah;
			$data['bb3'] = $key->berat_badan;
			$data['nadi3'] = $key->denyut_nadi;
			$data['suhu3'] = $key->suhu_badan;
			
		};

		$data['title'] = 'Detail pasien';
		$data['tpersalinan'] = 'Tidak Diketahui';
		$data['page'] = 'pasien';
		$this->template->load('temp', 'pasien/vd_pasien', $data);
	}

	public function hapus($id)
	{
		$where = array('id' => $id);
		$this->rsia->delete($where, 'pasien');
		echo "<script>alert('Data berhasil dihapus')</script>;";

		redirect('pasien','refresh');
		$this->session->flashdata('sukses');
	}

}

/* End of file Pasien.php */
/* Location: ./application/controllers/Pasien.php */