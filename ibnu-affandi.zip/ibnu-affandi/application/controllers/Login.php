<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {


	public function index()
	{

		if($this->rsia->logged_in())
		{

			redirect("home");

		} else {

			$this->form_validation->set_rules('username', 'Username', 'required');
			$this->form_validation->set_rules('password', 'Password', 'required');

			if ($this->form_validation->run() == TRUE) {

                //get data dari FORM
				$username = $this->input->post('username', TRUE);
				$password = MD5($this->input->post('password', TRUE));

                //checking data via model
				$checking = $this->rsia->check_login('pegawai', array('username' => $username), array('password' => $password));

                //jika ditemukan, maka create session
				if ($checking != FALSE) {
					foreach ($checking as $apps) {

						$session_data = array(
							'id_pegawai'   => $apps->id_pegawai,
							'nama' => $apps->nama,
							'username' => $apps->username,
							'password' => $apps->password,
							'hak_akses' => $apps->jabatan,
							'status' => TRUE
						);
                        //set session userdata
						$this->session->set_userdata($session_data);
						echo "<script>alert('Anda Berhasil Login')</script>";
						redirect('home','refresh');

					}
				}else{

					$data['error'] = '<div class="alert alert-danger" style="margin-top: 3px">
					<b><i class="fa fa-exclamation-circle"></i> ERROR</b> username atau password salah!
					</div>';
					$this->load->view('login_form', $data);
				}

			}else{

				$this->load->view('login_form');
			}

		}

	}
	
	public function logout()
	{
		$this->session->sess_destroy();
		redirect('login');
	}
}