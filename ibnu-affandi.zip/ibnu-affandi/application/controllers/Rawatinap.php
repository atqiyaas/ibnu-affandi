<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rawatinap extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('rsia');
	}

	public function cek_login()
	{
		if (!$this->rsia->logged_in()) 
		{
			redirect('login','refresh');
		}
	}

	public function index()
	{
		$this->cek_login();
		
		$data['rawat'] = $this->rsia->get_all('rawatinap');

		$data['title'] = 'Data Pasien Rawat Inap';
		$data['page'] = 'Pasien Rawat Inap';
		$this->template->load('temp', 'rawat/v_rawat', $data);
	}

	public function tambah()
	{
		if ($this->input->post('submit', TRUE) == 'Submit') {
			#validasi
			$this->form_validation->set_rules('nama_ruangan', 'No. Ruangan', 'required');
			$this->form_validation->set_rules('nama_pasien', 'Nama Pasien', 'required');
			

			if ($this->form_validation->run() == TRUE) {

				$data = array(
					'nama_ruangan' => $this->input->post('nama_ruangan', TRUE),
					'no_kasur' => $this->input->post('no_kasur', TRUE),
					'nama_pasien' => $this->input->post('nama_pasien', TRUE),
					'tanggal_masuk' => $this->input->post('tgl_masuk', TRUE),
				);

				$kasur = $this->input->post('no_kasur', TRUE);
				$ruang = $this->input->post('nama_ruangan', TRUE);

				$update = array(
					'status_kamar' => 'dipakai'
				);
				

				$this->rsia->insert('rawatinap', $data);
				$this->rsia->update('ruangan', $update, array('nama_ruangan' => $ruang, 'no_kasur' => $kasur));
				echo "<script>alert('Data pasien rawat inap berhasil ditambah')</script>";
				redirect('rawatinap','refresh');

			} 
		}

		$data['kamar'] = $this->rsia->get_where('ruangan', array('status_kamar' => 'kosong'));
		$data['pasien'] = $this->rsia->get_all('pasien');

		
		$data['title'] = 'Tambah Pasien Rawat Inap';
		$data['page'] = 'Rawat Inap';
		$this->template->load('temp', 'rawat/vt_rawat', $data);
	}

	public function edit()
	{
		$id = $this->uri->segment(3);

		if ($this->input->post('submit', TRUE) == 'Submit') {
			#validasi
			$this->form_validation->set_rules('nama_ruangan', 'No. Ruangan', 'required');
			$this->form_validation->set_rules('no_kasur', 'No. Kasur', 'required');
			

			if ($this->form_validation->run() == TRUE) {

				$pasienrawat = $this->rsia->get_where('rawatinap', array('no_rawat_inap' => $id));
				foreach ($pasienrawat->result() as $key) {
					$ruanglama = $key->nama_ruangan;
					$kasurlama = $key->no_kasur;
				}

				$data = array(
					'nama_ruangan' => $this->input->post('nama_ruangan', TRUE),
					'no_kasur' => $this->input->post('no_kasur', TRUE),
				);

				$kasur = $this->input->post('no_kasur', TRUE);
				$ruang = $this->input->post('nama_ruangan', TRUE);

				$update = array(
					'status_kamar' => 'dipakai'
				);

				$updatelama = array(
					'status_kamar' => 'kosong'
				);
				

				$this->rsia->update('rawatinap', $data, array('no_rawat_inap' => $id));

				$this->rsia->update('ruangan', $update, array('nama_ruangan' => $ruang, 'no_kasur' => $kasur));
				$this->rsia->update('ruangan', $updatelama, array('nama_ruangan' => $ruanglama, 'no_kasur' => $kasurlama));
				echo "<script>alert('Data pasien rawat inap berhasil diupdate')</script>";
				redirect('rawatinap','refresh');

			} 
		}

		
		$pasienrawat = $this->rsia->get_where('rawatinap', array('no_rawat_inap' => $id));
		foreach ($pasienrawat->result() as $key) {
			$data['nama_pasien'] = $key->nama_pasien;
			$data['nama_ruangan'] = $key->nama_ruangan;
			$data['no_kasur'] = $key->no_kasur;
			$data['status'] = $key->status_rawat;

		}
		
		$data['kamar'] = $this->rsia->get_where('ruangan', array('status_kamar' => 'kosong'));
		$data['pasien'] = $this->rsia->get_all('pasien');
		$data['title'] = 'Update Pasien Rawat Inap';
		$data['page'] = 'Rawat Inap';
		$this->template->load('temp', 'rawat/ve_rawat', $data);
	}

	public function keluar()
	{
		$id = $this->uri->segment(3);

		$pasienrawat = $this->rsia->get_where('rawatinap', array('no_rawat_inap' => $id));
		foreach ($pasienrawat->result() as $key) {
			$ruanglama = $key->nama_ruangan;
			$kasurlama = $key->no_kasur;
		}

		$keluar = date('d F Y');

		$update = array(
			'nama_ruangan' => NULL,
			'no_kasur' => NULL,
			'status_rawat' => 'Keluar',
			'tanggal_keluar' => $keluar
		);

		$updateruangan = array(
			'status_kamar' => 'kosong'
		);

		$this->rsia->update('rawatinap', $update, array('no_rawat_inap' => $id));
		$this->rsia->update('ruangan', $updateruangan, array('nama_ruangan' => $ruanglama, 'no_kasur' => $kasurlama));
		redirect('rawatinap','refresh');
	}
}

/* End of file Rawatinap.php */
/* Location: ./application/controllers/Rawatinap.php */