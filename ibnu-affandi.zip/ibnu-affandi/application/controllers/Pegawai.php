<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pegawai extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('rsia');
	}

	public function cek_login()
	{
		if (!$this->rsia->logged_in()) 
		{
			redirect('login','refresh');
		}
	}
	public function index()
	{
		$this->cek_login();

		$data['pegawai'] = $this->rsia->get_all('pegawai');
		$data['title'] = 'Data Pegawai';
		$data['page'] = 'Pegawai';
		$this->template->load('temp', 'pegawai/v_pegawai', $data);
	}
	
	public function tambah()
	{
		if ($this->input->post('submit', TRUE) == 'Submit') {
			#validasi
			$this->form_validation->set_rules('no_id', 'No. identitas', 'required');
			$this->form_validation->set_rules('nama', 'Nama Lengkap', 'required');
			$this->form_validation->set_rules('username', 'Username', 'required');
			$this->form_validation->set_rules('password', 'Password', 'required');
			$this->form_validation->set_rules('jk', 'Jenis Kelamin', 'required');
			$this->form_validation->set_rules('jabatan', 'Jabatan', 'required');
			$this->form_validation->set_rules('notelp', 'No. Telephone', 'required');
			$this->form_validation->set_rules('alamat', 'Alamat', 'required');

			if ($this->form_validation->run() == TRUE) {

				$data = array(
					'no_identitas' => $this->input->post('no_id', TRUE),
					'nama' => $this->input->post('nama', TRUE),
					'username' => $this->input->post('username', TRUE),
					'password' => md5($this->input->post('password', TRUE)),
					'jenis_kelamin' => $this->input->post('jk', TRUE),
					'jabatan' => $this->input->post('jabatan', TRUE),
					'telpon' => $this->input->post('notelp', TRUE),
					'alamat' => $this->input->post('alamat', TRUE),
				);
				

				$this->rsia->insert('pegawai', $data);
				echo "<script>alert('Data pegawai berhasil ditambah')</script>;";
				redirect('pegawai','refresh');

			} 
		}
		
		$data['title'] = 'Tambah Pegawai';
		$data['page'] = 'Pegawai';
		$this->template->load('temp', 'pegawai/vt_pegawai', $data);	
	}

	public function edit()
	{
		$id = $this->uri->segment(3);

		if ($this->input->post('submit', TRUE) == 'Submit') {

			$this->form_validation->set_rules('no_id', 'No. identitas', 'required');
			$this->form_validation->set_rules('nama', 'Nama Lengkap', 'required');
			$this->form_validation->set_rules('username', 'Username', 'required');
			$this->form_validation->set_rules('jk', 'Jenis Kelamin', 'required');
			$this->form_validation->set_rules('jabatan', 'Jabatan', 'required');
			$this->form_validation->set_rules('notelp', 'No. Telephone', 'required');
			$this->form_validation->set_rules('alamat', 'Alamat', 'required');
			$this->form_validation->set_rules('status', 'Status', 'required');

			if ($this->form_validation->run() == TRUE) {

				
				$update = array(
					'no_identitas' => $this->input->post('no_id', TRUE),
					'nama' => $this->input->post('nama', TRUE),
					'username' => $this->input->post('username', TRUE),
					'jenis_kelamin' => $this->input->post('jk', TRUE),
					'jabatan' => $this->input->post('jabatan', TRUE),
					'telpon' => $this->input->post('notelp', TRUE),
					'alamat' => $this->input->post('alamat', TRUE),
					'status_pegawai' => $this->input->post('status', TRUE),
				);
				$this->rsia->update('pegawai', $update, array('id_pegawai' => $id));
				echo "<script>alert('Data pegawai berhasil diupdate')</script>;";
				redirect('pegawai','refresh');

			} 
		}

		$pegawai = $this->rsia->get_where('pegawai', array('id_pegawai' => $id));

		foreach ($pegawai->result() as $key) {

			$data['no_id'] = $key->no_identitas;
			$data['nama'] = $key->nama;
			$data['username'] = $key->username;
			$data['jabatan'] = $key->jabatan;
			$data['notelp'] = $key->telpon;
			$data['jk'] = $key->jenis_kelamin;
			$data['status'] = $key->status_pegawai;
			$data['alamat'] = $key->alamat;
		}		

		$data['title'] = 'Edit Pegawai';
		$data['page'] = 'Pegawai';
		$this->template->load('temp', 'pegawai/ve_pegawai', $data);	
	}

	function detail()
	{
		$id_pegawai = $this->uri->segment(3);
		$pegawai = $this->rsia->get_where('pegawai', array('id_pegawai' => $id_pegawai));

		foreach ($pegawai->result() as $key) {

			$data['id_pegawai'] = $key->id_pegawai;
			$data['no_id'] = $key->no_identitas;
			$data['nama'] = $key->nama;
			$data['username'] = $key->username;
			$data['jabatan'] = $key->jabatan;
			$data['notelp'] = $key->telpon;
			$data['jk'] = $key->jenis_kelamin;
			$data['status'] = $key->status_pegawai;
			$data['alamat'] = $key->alamat;
		}
		$data['title'] = 'Detail Pegawai';
		$data['page'] = 'Pegawai';
		$this->template->load('temp', 'pegawai/vd_pegawai', $data);
	}
	public function hapus($id)
	{
		$where = array('id_pegawai' => $id);
		$this->rsia->delete($where, 'pegawai');
		echo "<script>alert('Data berhasil dihapus')</script>;";

		redirect('pegawai','refresh');
		$this->session->flashdata('sukses');
	}
}
