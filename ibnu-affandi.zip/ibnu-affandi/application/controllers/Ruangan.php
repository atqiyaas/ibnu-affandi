<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ruangan extends CI_Controller {

	public function cek_login()
	{
		if (!$this->rsia->logged_in()) 
		{
			redirect('login','refresh');
		}
	}

	public function index()
	{
		$this->cek_login();
		
		$data['title'] = 'Data Ruangan';
		$this->template->load('temp', 'v_ruangan', $data);
	}
}
