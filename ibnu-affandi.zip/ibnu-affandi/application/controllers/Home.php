<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function cek_login()
	{
		if (!$this->rsia->logged_in()) 
		{
			redirect('login','refresh');
		}
	}

	public function index()
	{
		$this->cek_login();
		
		$data['title'] = 'Beranda';
		$this->template->load('temp', 'v_beranda', $data);
	}
}
