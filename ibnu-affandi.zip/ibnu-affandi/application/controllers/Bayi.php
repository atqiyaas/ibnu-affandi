<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bayi extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('rsia');
	}

	public function cek_login()
	{
		if (!$this->rsia->logged_in()) 
		{
			redirect('login','refresh');
		}
	}

	public function index()
	{
		$this->cek_login();
		$data['bayi'] = $this->rsia->get_all('bayi');

		$data['title'] = 'Data Bayi';
		$data['page'] = 'Bayi';
		$this->template->load('temp', 'bayi/v_bayi', $data);
	}

	public function perbandingan()
	{
		$id = $this->uri->segment(3);
		
		if ($this->rsia->get_where('kontrolbayi', array('no_bayi' => $id, 'no_pk' => 'pk3' ))->result() == NULL) {
			echo "<script>alert('Belum Ada Data perbandingan, Silahkan lakukan pemeriksaan ke-3 terlebih dulu')</script>";
			redirect('bayi','refresh');
		} else {

			$bayi = $this->rsia->get_all('bayi');

			foreach ($bayi->result() as $key) {

				$data['id'] = $key->no_bayi;
				$data['ibu'] = $key->nama_ibu;
				$data['bayi'] = $key->nama_bayi;
				$data['tgl_lahir'] = $key->tanggal_kelahiran;
				$data['persalinan'] = $key->jenis_persalinan;
				$data['jk'] = $key->jenis_kelamin;
			};

			$data['kontrol1'] = $this->rsia->get_where('kontrolbayi', array('no_bayi' => $id, 'no_pk' => 'pk1'));
			$data['kontrol2'] = $this->rsia->get_where('kontrolbayi', array('no_bayi' => $id, 'no_pk' => 'pk2'));
			$data['kontrol3'] = $this->rsia->get_where('kontrolbayi', array('no_bayi' => $id, 'no_pk' => 'pk3'));


			$kontrol1 = $this->rsia->get_where('kontrolbayi', array('no_bayi' => $id, 'no_pk' => 'pk1'));
			$kontrol2 = $this->rsia->get_where('kontrolbayi', array('no_bayi' => $id, 'no_pk' => 'pk2'));
			$kontrol3 = $this->rsia->get_where('kontrolbayi', array('no_bayi' => $id, 'no_pk' => 'pk3'));

			foreach ($kontrol1->result() as $key) {

				$data['bb'] = $key->berat_badan;
				$data['jantung'] = $key->frekuensi_jantung;
				$data['suhu'] = $key->suhu_badan;
				$data['bernafas'] = $key->usaha_bernafas;
				$data['kepala'] = $key->lingkar_kepala;
				$data['dada'] = $key->lingkar_dada;
				$data['otot'] = $key->tonus_otot;
				$data['kulit'] = $key->warna_kulit;
				$data['panjang'] = $key->panjang_badan;
				$data['berkedip'] = $key->berkedip;
				$data['moros'] = $key->moros;
				$data['menggenggam'] = $key->menggenggam;
				$data['menghisap'] = $key->menghisap;
				$data['rooting'] = $key->rooting;
				$data['tgl_periksa'] = $key->tanggal_pemeriksaan;
			};

			foreach ($kontrol2->result() as $key) {

				$data['bb2'] = $key->berat_badan;
				$data['jantung2'] = $key->frekuensi_jantung;
				$data['suhu2'] = $key->suhu_badan;
				$data['bernafas2'] = $key->usaha_bernafas;
				$data['kepala2'] = $key->lingkar_kepala;
				$data['dada2'] = $key->lingkar_dada;
				$data['otot2'] = $key->tonus_otot;
				$data['kulit2'] = $key->warna_kulit;
				$data['panjang2'] = $key->panjang_badan;
				$data['berkedip2'] = $key->berkedip;
				$data['moros2'] = $key->moros;
				$data['menggenggam2'] = $key->menggenggam;
				$data['menghisap2'] = $key->menghisap;
				$data['rooting2'] = $key->rooting;
				$data['tgl_periksa2'] = $key->tanggal_pemeriksaan;
			};

			foreach ($kontrol3->result() as $key) {

				$data['bb3'] = $key->berat_badan;
				$data['jantung3'] = $key->frekuensi_jantung;
				$data['suhu3'] = $key->suhu_badan;
				$data['bernafas3'] = $key->usaha_bernafas;
				$data['kepala3'] = $key->lingkar_kepala;
				$data['dada3'] = $key->lingkar_dada;
				$data['otot3'] = $key->tonus_otot;
				$data['kulit3'] = $key->warna_kulit;
				$data['panjang3'] = $key->panjang_badan;
				$data['berkedip3'] = $key->berkedip;
				$data['moros3'] = $key->moros;
				$data['menggenggam3'] = $key->menggenggam;
				$data['menghisap3'] = $key->menghisap;
				$data['rooting3'] = $key->rooting;
				$data['tgl_periksa3'] = $key->tanggal_pemeriksaan;
			};

			$data['title'] = 'Perbandingan Kontrol Bayi';
			$data['page'] = 'Bayi';

			$this->template->load('temp', 'bayi/perbandingan', $data);
		}
		
	}


	public function tambah()
	{
		if ($this->input->post('submit', TRUE) == 'Submit') {
			#validasi
			$this->form_validation->set_rules('nama_bayi', 'Nama Lengkap Bayi', 'required');
			$this->form_validation->set_rules('nama_ibu', 'Nama Ibu Bayi', 'required');
			$this->form_validation->set_rules('jk', 'Jenis Kelamin', 'required');
			$this->form_validation->set_rules('persalinan', 'Jenis Persalinan', 'required');
			$this->form_validation->set_rules('tgl_lahir_bayi', 'Tanggal kelahiran bayi', 'required');

			if ($this->form_validation->run() == TRUE) {

				$data = array(
					'nama_ibu' => $this->input->post('nama_ibu', TRUE),
					'nama_bayi' => $this->input->post('nama_bayi', TRUE),
					'jenis_kelamin' => $this->input->post('jk', TRUE),
					'jenis_persalinan' => $this->input->post('persalinan', TRUE),
					'tanggal_kelahiran' => $this->input->post('tgl_lahir_bayi', TRUE),
				);
				

				$this->rsia->insert('bayi', $data);
				echo "<script>alert('Data Bayi berhasil ditambah')</script>";
				redirect('bayi','refresh');

			} 
		}
		
		$data['title'] = 'Tambah Bayi';
		$data['page'] = 'Bayi';
		$data['rawat'] = $this->rsia->get_all('rawatinap');

		$this->template->load('temp', 'bayi/vt_bayi', $data);
	}

	/* tambah data riwayat kesehatan */

	public function add_rk()
	{
		$id = $this->uri->segment(3);

		if ($this->input->post('submit', TRUE) == 'Submit') {
			#validasi
			$this->form_validation->set_rules('no', 'Nomor pasien', 'required');
			// $this->form_validation->set_rules('tgl_periksa', 'Tanggal Pemeriksaan', 'required');
			$this->form_validation->set_rules('no_rk', 'Pemeriksaan Ke-', 'required');
			$this->form_validation->set_rules('kesadaran', 'Kesadaran Pasien', 'required');
			$this->form_validation->set_rules('tensi', 'Tensi Darah', 'required');
			$this->form_validation->set_rules('nadi', 'Denyut Nadi', 'required');
			$this->form_validation->set_rules('suhu', 'Suhu Badan', 'required');
			$this->form_validation->set_rules('keadaan', 'Keadaan Umum', 'required');
			$this->form_validation->set_rules('bb', 'Berat Badan', 'required');

			if ($this->form_validation->run() == TRUE) {

				$data = array(
					'no_pasien' => $this->input->post('no', TRUE),
					'tanggal_pemeriksaan' => date('d F Y'),
					'no_rk' => $this->input->post('no_rk', TRUE),
					'kesadaran_pasien' => $this->input->post('kesadaran', TRUE),
					'keadaan_umum' => $this->input->post('keadaan', TRUE),
					'tensi_darah' => $this->input->post('tensi', TRUE),
					'denyut_nadi' => $this->input->post('nadi', TRUE),
					'suhu_badan' => $this->input->post('suhu', TRUE),
					'berat_badan' => $this->input->post('bb', TRUE),
				);
				

				$this->rsia->insert('riwayatkesehatan', $data);
				echo "<script>alert('Data riwayat kesahatan berhasil ditambah')</script>";
				redirect('pasien','refresh');

			} 
		}
		$pasien = $this->rsia->get_where('pasien', array('no_pasien' => $id));

		foreach ($pasien->result() as $key) {

			$data['no_id'] = $key->no_identitas;
			$data['no_pasien'] = $key->no_pasien;
			$data['nama'] = $key->nama;
		}		
		
		$data['title'] = 'Input Riwayat Kesehatan';
		$data['page'] = 'Pasien';
		$this->template->load('temp', 'bayi/add_rkesehatan', $data);
	}

	/*end of tambah data riwayat kesehatan*/

	/* tambah data Pemeriksaan Kehamilan*/

	public function add_pk()
	{
		$id = $this->uri->segment(3);

		if ($this->input->post('submit', TRUE) == 'Submit') {
			#validasi
			$this->form_validation->set_rules('bb', 'Berat Badan', 'required');
			$this->form_validation->set_rules('jantung', 'Frekuensi Jantung', 'required');
			$this->form_validation->set_rules('suhu', 'Suhu Badan', 'required');
			$this->form_validation->set_rules('kepala', 'Lingkar Kepala', 'required');
			$this->form_validation->set_rules('panjang', 'Panjang Badan', 'required');
			$this->form_validation->set_rules('dada', 'Lingkar Dada', 'required');
			$this->form_validation->set_rules('dada', 'Lingkar Dada', 'required');
			
			

			if ($this->form_validation->run() == TRUE) {

				$data = array(
					'no_bayi' => $this->input->post('id', TRUE),
					'tanggal_pemeriksaan' => $this->input->post('tgl_periksa', TRUE),
					'no_pk' => $this->input->post('no_pk', TRUE),
					'berat_badan' => $this->input->post('bb', TRUE),
					'frekuensi_jantung' => $this->input->post('jantung', TRUE),
					'suhu_badan' => $this->input->post('suhu', TRUE),
					'lingkar_kepala' => $this->input->post('kepala', TRUE),
					'panjang_badan' => $this->input->post('panjang', TRUE),
					'lingkar_dada' => $this->input->post('dada', TRUE),
					'usaha_bernafas' => $this->input->post('bernafas', TRUE),
					'berkedip' => $this->input->post('berkedip', TRUE),
					'menggenggam' => $this->input->post('genggam', TRUE),
					'rooting' => $this->input->post('rooting', TRUE),
					'warna_kulit' => $this->input->post('kulit', TRUE),
					'moros' => $this->input->post('moros', TRUE),
					'menghisap' => $this->input->post('menghisap', TRUE),
					'tonus_otot' => $this->input->post('otot', TRUE),
				);
				

				$this->rsia->insert('kontrolbayi', $data);
				echo "<script>alert('Data Kontrol Bayi berhasil ditambah')</script>";
				redirect('bayi','refresh');

			} 
		}

		$bayi = $this->rsia->get_where('bayi', array('no_bayi' => $id));

		foreach ($bayi->result() as $key) {

			$data['id'] = $key->no_bayi;
			$data['ibu'] = $key->nama_ibu;
			$data['bayi'] = $key->nama_bayi;
			$data['tgl_lahir'] = $key->tanggal_kelahiran;
			$data['persalinan'] = $key->jenis_persalinan;
			$data['jk'] = $key->jenis_kelamin;
		};			
		
		$data['title'] = 'Input Kontrol Bayi';
		$data['page'] = 'Bayi';
		$this->template->load('temp', 'bayi/kontrol', $data);
	}

	/*end of tambah data Pemeriksaan Kehamilan*/

	public function edit()
	{
		$id = $this->uri->segment(3);

		if ($this->input->post('submit', TRUE) == 'Submit') {

			$this->form_validation->set_rules('nama_bayi', 'Nama Lengkap Bayi', 'required');
			$this->form_validation->set_rules('nama_ibu', 'Nama Ibu Bayi', 'required');
			$this->form_validation->set_rules('jk', 'Jenis Kelamin', 'required');
			$this->form_validation->set_rules('persalinan', 'Jenis Persalinan', 'required');
			$this->form_validation->set_rules('tgl_lahir_bayi', 'Tanggal kelahiran bayi', 'required');

			if ($this->form_validation->run() == TRUE) {

				
				$update = array(
					'nama_ibu' => $this->input->post('nama_ibu', TRUE),
					'nama_bayi' => $this->input->post('nama_bayi', TRUE),
					'jenis_kelamin' => $this->input->post('jk', TRUE),
					'jenis_persalinan' => $this->input->post('persalinan', TRUE),
					'tanggal_kelahiran' => $this->input->post('tgl_lahir_bayi', TRUE),
				);
				$this->rsia->update('bayi', $update, array('no_bayi' => $id));
				echo "<script>alert('Data bayi berhasil diupdate')</script>;";
				redirect('bayi','refresh');

			} 
		}

		$bayi = $this->rsia->get_where('bayi', array('no_bayi' => $id));

		foreach ($bayi->result() as $key) {

			$data['id'] = $key->no_bayi;
			$data['ibu'] = $key->nama_ibu;
			$data['bayi'] = $key->nama_bayi;
			$data['tgl_lahir'] = $key->tanggal_kelahiran;
			$data['persalinan'] = $key->jenis_persalinan;
			$data['jk'] = $key->jenis_kelamin;
		};		

		$data['title'] = 'Edit bayi';

		$data['page'] = 'bayi';
		$this->template->load('temp', 'bayi/ve_bayi', $data);	
	}
	public function proses()
	{
		$id = $this->uri->segment(3);

		if ($this->input->post('submit', TRUE) == 'Submit') {

			$this->form_validation->set_rules('usia_nikah', 'Usia Pernikahan', 'required');
			$this->form_validation->set_rules('jkb', 'Jenis KB', 'required');
			$this->form_validation->set_rules('lama_kb', 'Lama Pemakaian', 'required');
			$this->form_validation->set_rules('hpht', 'Tanggal HPHT', 'required');
			$this->form_validation->set_rules('hpl', 'Tanggal HPL', 'required');
			$this->form_validation->set_rules('hamil_ke', 'Hamil Ke-', 'required');
			$this->form_validation->set_rules('jml_anak', 'Jumlah anak', 'required');
			$this->form_validation->set_rules('riw_keg', 'Riwayat Keguguran', 'required');
			$this->form_validation->set_rules('riw_per', 'Riwayat Persalinan', 'required');
			$this->form_validation->set_rules('bayi', 'Kesehatan Bayi', 'required');
			$this->form_validation->set_rules('berat', 'Berat Badan', 'required');
			$this->form_validation->set_rules('jper', 'jenis persalinan', 'required');
			$this->form_validation->set_rules('tempat_per', 'Tempat persalinan', 'required');
			$this->form_validation->set_rules('usia_hamil', 'Usia Kehamilan', 'required');
			$this->form_validation->set_rules('phamil', 'Pernah Hamil?', 'required');

			if ($this->form_validation->run() == TRUE) {

				
				$update = array(
					'usia_pernikahan' => $this->input->post('usia_nikah', TRUE),
					'jenis_kb' => $this->input->post('jkb', TRUE),
					'lama_pemakaian' => $this->input->post('lama_kb', TRUE),
					'tanggal_hpht' => $this->input->post('hpht', TRUE),
					'tanggal_hpl' => $this->input->post('hpl', TRUE),
					'hamil_ke' => $this->input->post('hamil_ke', TRUE),
					'jumlah_anak' => $this->input->post('jml_anak', TRUE),
					'riwayat_keguguran' => $this->input->post('riw_keg', TRUE),
					'riwayat_persalinan' => $this->input->post('riw_per', TRUE),
					'kesehatan_bayi' => $this->input->post('bayi', TRUE),
					'berat_badan' => $this->input->post('berat', TRUE),
					'jenis_persalinan' => $this->input->post('jper', TRUE),
					'tempat_persalinan' => $this->input->post('tempat_per', TRUE),
					'usia_kehamilan' => $this->input->post('usia_hamil', TRUE),
					'pernah_hamil' => $this->input->post('phamil', TRUE),
				);
				$this->rsia->update('pasien', $update, array('no_pasien' => $id));
				echo "<script>alert('Data pasien berhasil diupdate')</script>;";
				redirect('pasien','refresh');

			} 
		}

		$pasien = $this->rsia->get_where('pasien', array('no_pasien' => $id));

		foreach ($pasien->result() as $key) {

			$data['no_id'] = $key->no_identitas;
			$data['nama'] = $key->nama;
			$data['suami'] = $key->nama_suami;
			$data['notelp'] = $key->no_telpon;
			$data['jk'] = $key->jenis_kelamin;
			$data['status'] = $key->status_pasien;
			$data['alamat'] = $key->alamat;
		}		

		$data['title'] = 'Edit pasien';
		$data['page'] = 'pasien';
		$this->template->load('temp', 'bayi/vp_pasien', $data);	
	}

	function detail()
	{
		$id = $this->uri->segment(3);

		$bayi = $this->rsia->get_where('bayi', array('no_bayi' => $id));

		foreach ($bayi->result() as $key) {

			$data['id'] = $key->no_bayi;
			$data['ibu'] = $key->nama_ibu;
			$data['bayi'] = $key->nama_bayi;
			$data['tgl_lahir'] = $key->tanggal_kelahiran;
			$data['persalinan'] = $key->jenis_persalinan;
			$data['jk'] = $key->jenis_kelamin;
		};

		$data['kontrol1'] = $this->rsia->get_where('kontrolbayi', array('no_bayi' => $id, 'no_pk' => 'pk1'));
		$data['kontrol2'] = $this->rsia->get_where('kontrolbayi', array('no_bayi' => $id, 'no_pk' => 'pk2'));
		$data['kontrol3'] = $this->rsia->get_where('kontrolbayi', array('no_bayi' => $id, 'no_pk' => 'pk3'));


		$kontrol1 = $this->rsia->get_where('kontrolbayi', array('no_bayi' => $id, 'no_pk' => 'pk1'));
		$kontrol2 = $this->rsia->get_where('kontrolbayi', array('no_bayi' => $id, 'no_pk' => 'pk2'));
		$kontrol3 = $this->rsia->get_where('kontrolbayi', array('no_bayi' => $id, 'no_pk' => 'pk3'));

		foreach ($kontrol1->result() as $key) {

			$data['bb'] = $key->berat_badan;
			$data['jantung'] = $key->frekuensi_jantung;
			$data['suhu'] = $key->suhu_badan;
			$data['bernafas'] = $key->usaha_bernafas;
			$data['kepala'] = $key->lingkar_kepala;
			$data['dada'] = $key->lingkar_dada;
			$data['otot'] = $key->tonus_otot;
			$data['kulit'] = $key->warna_kulit;
			$data['panjang'] = $key->panjang_badan;
			$data['berkedip'] = $key->berkedip;
			$data['moros'] = $key->moros;
			$data['menggenggam'] = $key->menggenggam;
			$data['menghisap'] = $key->menghisap;
			$data['rooting'] = $key->rooting;
			$data['tgl_periksa'] = $key->tanggal_pemeriksaan;
		};

		foreach ($kontrol2->result() as $key) {

			$data['bb2'] = $key->berat_badan;
			$data['jantung2'] = $key->frekuensi_jantung;
			$data['suhu2'] = $key->suhu_badan;
			$data['bernafas2'] = $key->usaha_bernafas;
			$data['kepala2'] = $key->lingkar_kepala;
			$data['dada2'] = $key->lingkar_dada;
			$data['otot2'] = $key->tonus_otot;
			$data['kulit2'] = $key->warna_kulit;
			$data['panjang2'] = $key->panjang_badan;
			$data['berkedip2'] = $key->berkedip;
			$data['moros2'] = $key->moros;
			$data['menggenggam2'] = $key->menggenggam;
			$data['menghisap2'] = $key->menghisap;
			$data['rooting2'] = $key->rooting;
			$data['tgl_periksa2'] = $key->tanggal_pemeriksaan;
		};

		foreach ($kontrol3->result() as $key) {

			$data['bb3'] = $key->berat_badan;
			$data['jantung3'] = $key->frekuensi_jantung;
			$data['suhu3'] = $key->suhu_badan;
			$data['bernafas3'] = $key->usaha_bernafas;
			$data['kepala3'] = $key->lingkar_kepala;
			$data['dada3'] = $key->lingkar_dada;
			$data['otot3'] = $key->tonus_otot;
			$data['kulit3'] = $key->warna_kulit;
			$data['panjang3'] = $key->panjang_badan;
			$data['berkedip3'] = $key->berkedip;
			$data['moros3'] = $key->moros;
			$data['menggenggam3'] = $key->menggenggam;
			$data['menghisap3'] = $key->menghisap;
			$data['rooting3'] = $key->rooting;
			$data['tgl_periksa3'] = $key->tanggal_pemeriksaan;
		};

		
		$data['title'] = 'Detail Bayi';
		$data['tpersalinan'] = 'Tidak Diketahui';
		$data['page'] = 'Bayi';
		$this->template->load('temp', 'bayi/vd_bayi', $data);
	}

	public function hapus($id)
	{
		$where = array('no_bayi' => $id);
		$this->rsia->delete($where, 'bayi');
		echo "<script>alert('Data berhasil dihapus')</script>;";

		redirect('bayi','refresh');
		$this->session->flashdata('sukses');
	}

}

/* End of file Pasien.php */
/* Location: ./application/controllers/Bayi.php */